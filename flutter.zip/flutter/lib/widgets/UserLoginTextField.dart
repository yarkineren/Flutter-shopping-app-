import 'package:cs308_plaqstore/forms/loginForm.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import 'package:cs308_plaqstore/flutter_api/bloc/login_bloc.dart';


class UserLoginTextField extends StatelessWidget
{
  Function(String) onSaved;
  InputDecoration decoration;
  Function(String) validator;
  final bool isObscure;

  UserLoginTextField({this.isObscure, this.decoration, this.validator, this.onSaved});

  @override
  Widget build(BuildContext context){
    return TextFormField(
        obscureText: isObscure,
        decoration: decoration,
        validator:validator,
        onSaved:onSaved);
  }
}


//SUBMIT BUTTON OF LOGIN
class UserLoginButton extends StatelessWidget{
  final Function() onPressed;
  UserLoginButton({this.onPressed});

  @override
  Widget build(BuildContext context)
  {
    return SizedBox(child:RaisedButton(onPressed: onPressed,
      child: Text('Login'),),width:double.infinity);
  }
}

