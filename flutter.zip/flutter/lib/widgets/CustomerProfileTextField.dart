import 'package:flutter/material.dart';

//CHECK THIS AGAIN
class CustomerProfileTextField extends StatelessWidget {
  Function(String) onSaved;
  InputDecoration decoration;
  Function(String) validator;
  final bool isObscure;

  CustomerProfileTextField(
      {this.isObscure, this.decoration, this.validator, this.onSaved});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
        obscureText: isObscure,
        decoration: decoration,
        validator: validator,
        onSaved: onSaved);
  }
}

//BUTTONS ON PROFILE PAGE
class Customer_MyOrdersButton extends StatelessWidget{
  final Function() onPressed;
  Customer_MyOrdersButton({this.onPressed});

  @override
  Widget build(BuildContext context)
  {
    return (RaisedButton(onPressed: onPressed,
      child: Text('My Orders')));
  }
}

class Customer_ReviewsButton extends StatelessWidget{
  final Function() onPressed;
  Customer_ReviewsButton({this.onPressed});

  @override
  Widget build(BuildContext context)
  {
    return (RaisedButton(onPressed: onPressed,
        child: Text('My Reviews')));
  }
}

class Customer_SettingsButton extends StatelessWidget{
  final Function() onPressed;
  Customer_SettingsButton({this.onPressed});

  @override
  Widget build(BuildContext context)
  {
    return (RaisedButton(onPressed: onPressed,
        child: Text('Settings')));
  }
}


