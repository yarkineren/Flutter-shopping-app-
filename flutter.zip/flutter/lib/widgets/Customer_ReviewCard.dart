import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/model.dart';


class Customer_ReviewCard extends StatelessWidget {
  final Customer_Review review;

  Customer_ReviewCard({this.review});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.fromLTRB(0, 8.0, 0.0, 8.0),
      child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(review.text,
                style: TextStyle(
                  fontSize: 18.0,
                  color: AppColors.textColor,
                )
            ),
      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          Text(review.date,
            style: TextStyle(
              fontSize: 12.0,
              color: AppColors.textColor,
            )
          ),
        SizedBox(width: 8.0),
          Icon(
            Icons.thumb_up,
            size: 12.0,
            color:AppColors.primary,
          ),

        Text('${review.likes}',
          style: TextStyle(
            fontSize: 12.0,
            color: AppColors.textColor,
          )
        ),
          SizedBox(width: 8.0),

          Icon(
            Icons.comment,
            size: 12.0,
            color:AppColors.primary,
          ),

          Text('${review.comments}',
              style: TextStyle(
                fontSize: 12.0,
                color: AppColors.textColor,
              )
          ),
        ]

      )


          ]
      )

      ),
    );
  }

}