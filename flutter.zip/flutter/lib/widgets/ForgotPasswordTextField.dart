import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/model.dart';

class ForgotPasswordScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("I Forgot My Password"),
      ),
    );
  }
}