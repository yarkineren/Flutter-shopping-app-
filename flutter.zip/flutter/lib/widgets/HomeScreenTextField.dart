import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import'package:cs308_plaqstore/model.dart';
import'package:cs308_plaqstore/forms/loginForm.dart';


goToLogIn(BuildContext context) //when logged out
{
  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginForm()),);
}


class HomeScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('HomeScreen'),
      ),
      body:
          
            Padding(
              padding: EdgeInsets.fromLTRB(34.0, 20.0, 0.0, 0.0),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.85,
                height: MediaQuery.of(context).size.width * 0.16,
                child: RaisedButton(
                  child: Text(
                    'Logout',
                    style: TextStyle(
                      fontSize: 24,
                    ),
                  ),
                  onPressed: () {
                    BlocProvider.of<AuthenticationBloc>(context)
                        .add(LoggedOut());
                      goToLogIn(context);
                  },
                  shape: StadiumBorder(
                    side: BorderSide(
                      color: AppColors.headingColor,
                      width: 2,
                    ),
                  ),
                  color: AppColors.primary,
                ),
              ),
            ),
    );
  }
}