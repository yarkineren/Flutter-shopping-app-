library my_prj.globals;
//import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/model.dart';

List<Product> Mycart= [];
String globalusername;
int global_customer_id;
double global_sum=0;