class Product {
  String model_no;
  String artist_name;
  String album_name;
  String description;
  String genre;
  String warranty;
  String distributor;
  String price;
  String stock;
  String image;

  Product(
      {this.model_no,
        this.artist_name,
        this.album_name,
        this.genre,
        this.warranty,
        this.distributor,
        this.price,
        this.stock,
        this.description,
        this.image,
      });

  factory Product.fromDatabaseJson(Map<String, dynamic> data) => Product(
    model_no: data['model_no'],
    album_name: data['album_name'],
    artist_name: data['artist_name'],
    description: data['description'], //token
    genre: data['genre'],
    warranty: data['warranty'],
    distributor: data['distributor'],
    price: data['price'],
    stock: data['stock'],
    image: data['image'],
  );

  Map<String, dynamic> toDatabaseJson() => {
    "model_no": this.model_no,
    "artist_name": this.artist_name,
    "album_name": this.album_name,
    "genre": this.genre,
    "warrantry": this.warranty,
    "distributor": this.distributor,
    "price": this.price,
    "stock": this.stock,
    "description": this.description,
    'image': this.image,
  };
  
  @override
  toString() => "model_no: $model_no , album_name: $album_name, artist_name: $artist_name stock: $stock, image: $image" ;

}

