import 'package:cs308_plaqstore/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'forms/loginForm.dart';
//import 'package:flutter/main.dart';

void main() {
  testWidgets('Counter increments checking test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    //await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Tap the '+' icon and trigger a frame.
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // Verify that our counter has incremented.
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);
  });
}

void main2() {

  test('empty username returns error string', () {

    final result = UserFieldValidator.validate('');
    expect(result, 'username can\'t be empty');
  });

  test('non-empty username returns null', () {

    final result = UserFieldValidator.validate('username');
    expect(result, null);
  });

  test('valid username returns string', () {

    final result = UserVFieldValidator.validate('username');
    expect(result, 'username is valid');
  });

  test('invalid username returns string', () {

    final result = UserIFieldValidator.validate('username');
    expect(result, 'username is invalid');
  });

  test('empty password returns error string', () {

    final result = PasswordFieldValidator.validate('');
    expect(result, 'password can\'t be empty');
  });

  test('non-empty password returns null', () {

    final result = PasswordFieldValidator.validate('password');
    expect(result, null);
  });

  test('valid password returns string', () {

    final result = PasswordVFieldValidator.validate('');
    expect(result, 'password is valid');
  });

  test('invalid password returns string', () {

    final result = PasswordIFieldValidator.validate('');
    expect(result, 'password is invalid');
  });

  test('empty email returns error string', () {

    final result = EmailFieldValidator.validate('email');
    expect(result, 'email can\'t be empty');
  });

  test('non-empty e-mail returns null', () {

    final result = EmailFieldValidator.validate('email');
    expect(result, null);
  });

  test('valid email returns string', () {

    final result = EmailVFieldValidator.validate('email');
    expect(result, 'email is valid');
  });

  test('invalid email returns string', () {

    final result = EmailIFieldValidator.validate('email');
    expect(result, 'email is invalid');
  });




}