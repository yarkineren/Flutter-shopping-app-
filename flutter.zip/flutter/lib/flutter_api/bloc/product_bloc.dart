/*

import 'package:bloc/bloc.dart';
import'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:equatable/equatable.dart';
import 'dart:async';
import 'package:flutter/material.dart';


abstract class ConnectionState extends Equatable {

  const ConnectionState();
  @override
  List<Object> get props => [];
}

class ConnectionInitial extends ConnectionState {}

class ConnectionLoading extends ConnectionState {}

class ConnectionFailure extends ConnectionState {
  final String error;

  const ConnectionFailure({@required this.error});

  @override
  List<Object> get props => [error];

  @override
  String toString() => ' Unable to connect right now"';
}


abstract class ConnectionEvent extends Equatable {
  const ConnectionEvent();
}

class ProductsBloc extends BlocListener {
  final UserRepository userRepository;
  final AuthenticationBloc authenticationBloc;

  ProductsBloc({
    @required this.userRepository,
    @required this.authenticationBloc,
  })
      : assert(userRepository != null),
        assert(authenticationBloc != null);

  @override
  ConnectionState get initialState => ConnectionInitial();
}


 */