part of 'authentication_bloc.dart';
//app is waitin to check if user exists in database or not
//auntheticated state = successful login
//unauthenticated state = user is logged out

abstract class AuthenticationState extends Equatable {
  @override
  List<Object> get props => [];
}

class AuthenticationUnintialized extends AuthenticationState {}

class AuthenticationAuthenticated extends AuthenticationState {}

class AuthenticationUnauthenticated extends AuthenticationState {}

class AuthenticationLoading extends AuthenticationState {}