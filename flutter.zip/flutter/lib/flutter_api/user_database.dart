import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

final userTable = 'userTable';
final productTable = 'productTable';

class DatabaseProvider {
  static final DatabaseProvider dbProvider = DatabaseProvider();

  Database _database;

  Future <Database> get database async {
    print("UserDatabase getDatabase");
    if (_database != null){
      return _database;
    }
    _database = await createDatabase();
    return _database;
  }

  createDatabase() async {
    print("UserDatabase createDatabase");

    //NOT WORKING
   Directory documentsDirectory = await getApplicationDocumentsDirectory();

    //Directory documentsDirectory = await getTemporaryDirectory();
    print("UserDatabase docDirectory works");
    String path = join(documentsDirectory.path, "User.db");
    print("UserDatabase path works");

    var database = await openDatabase(
      path,
      version: 1,
      onCreate: initDB,
      onUpgrade: onUpgrade,
    );
    print("UserDatabase is returned");
    return database;
  }

  void onUpgrade(
      Database database,
      int oldVersion,
      int newVersion,
      ){
    print("UserDatabase onUpgrade");
    if (newVersion > oldVersion){}
  }

  void initDB(Database database, int version) async {
    print("UserDatabase initDb");
    await database.execute(
        "CREATE TABLE $userTable ("
            "id INTEGER PRIMARY KEY, "
            "username TEXT, "            "token TEXT "
            ")"
    );
    //PRODUCTS
    await database.execute( //token
        "CREATE TABLE $productTable ("
            "model_no TEXT PRIMARY KEY, "
            "artist_name TEXT, "            "album_name TEXT "
            "genre TEXT, "            "warrantry TEXT "
            "distributor TEXT, "            "price TEXT "
            "stock TEXT, "            "description TEXT "
            ")"
    );
  }
}