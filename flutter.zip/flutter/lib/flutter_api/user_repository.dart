
import 'dart:async';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/api_model.dart';
import 'package:meta/meta.dart';
import 'package:cs308_plaqstore/flutter_api/api.dart';
import 'package:cs308_plaqstore/flutter_api/user_database.dart';
import 'package:cs308_plaqstore/flutter_api/user_dao.dart';
import 'package:cs308_plaqstore/globals.dart';

String mytoken;

class UserRepository {
  final userDao = UserDao();

  Future<User> authenticate ({
    @required String username,
    @required String password,
  }) async {
    print("UserRepository Authenticate");
    UserLogin userLogin = UserLogin(
        username: username,
        password: password
    );
    Token token = await getToken(userLogin);
    User user = User(
      id: 0,
      username: username,
      token: token.token,
    );

    mytoken = token.toString();
    globalusername = username.toString();
    print("UserRepo User Constructor");

    return user;
  }

  Future<void> persistToken ({
    @required User user
  }) async {
    // write token with the user to the database
    await userDao.createUser(user);
    print("UserRepo Persist Token");
  }

  Future <void> deleteToken({
    @required int id
  }) async {
    await userDao.deleteUser(id);
    print("UserRepo Delete Token");
  }

  Future <bool> hasToken() async {
    bool result = await userDao.checkUser(0);
    return result;
  }


  //Future<String> showToken({
    //@required User user
//}) async{
  //  print("UserRepo Show Token works");
    //String token = await userDao.getUserToken(0);
    //print("UserRepo Show Token works2");
    //print(token);
    //return token;
  //}
}
