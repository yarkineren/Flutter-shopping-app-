import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/flutter_api/user_database.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:core';

//to create a user/delete a user and search the existence of user


class UserDao {
  final dbProvider = DatabaseProvider.dbProvider;

  Uri getUser(String username) =>
      Uri.parse(
          'http://10.0.2.2:8000/api/example/?username=' + username);

  Future<dynamic> searchUser(String username) async {
    final uri = getUser(username);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }

  Future<List<Customer_Profile>> _parseUser(String username) async {
    List<Customer_Profile> productsList = <Customer_Profile>[];
    print("UserDao parseUser");

    var dataFromResponse = await searchUser(username);

    dataFromResponse.forEach(
          (User) {
        //parse new product's details
        Customer_Profile thisuser = new Customer_Profile(
          Name: User["first_name"],
          Surname: User["last_name"],
          emailAddress: User["email"],
          id: User["id"],
        );

        print(thisuser);
        global_customer_id = thisuser.id;
        print("This user's customer id is set as " + thisuser.id.toString() + "in user_dao");
        productsList.add(thisuser);
      },
    );
    return productsList;
  }

  Future<int> createUser(User user) async {

    print("UserDao CreateUser");
    final db = await dbProvider.database;
    var result = db.insert(userTable, user.toDatabaseJson());
    var check = await checkUser(0);
    return result;
  }


  Future<int> deleteUser(int id) async {
    print("UserDao DeleteUser");
    final db = await dbProvider.database;
    var result = await db
        .delete(userTable, where: "id = ?", whereArgs: [id]);
    return result;
  }

  Future<bool> checkUser(int id) async {
    print("UserDao CheckUser");
    final db = await dbProvider.database;
    try {
      List<Map> users = await db
          .query(userTable, where: 'id = ?', whereArgs: [id]);
      if (users.length > 0) {
        print(users.toString());
        globalusername = await users[0]["username"];
        print(globalusername + " is set as global username in user_dao");
        var setGlobalCustomerId = await _parseUser(globalusername);

        return true;
      } else {
        return false;
      }
    } catch (error) {
      return false;
    }
  }
  Future<String> getUserToken(int id) async {
    print("Userdao getUsertoken");
    final db = await dbProvider.database;
    try {
      var res = await db.rawQuery("SELECT token FROM userTable WHERE id=0");
      print("Userdao getUsertoken2");
      return res.isNotEmpty ? (User.fromDatabaseJson(res.first)).token : null;
    } catch (err) {
      return null;
    }
  }


}

