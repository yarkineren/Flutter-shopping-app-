import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/flutter_api/user_database.dart';


class ProductDao {
  final dbProvider = DatabaseProvider.dbProvider;

  Future<int> createProduct(Product product) async {
    print("ProductDao CreateProduct");
    final db = await dbProvider.database;
    var result = db.insert(productTable, product.toDatabaseJson());
    return result;
  }
}