/*

import 'dart:async';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/api_model.dart';
import 'package:meta/meta.dart';

class ProductRepository {

  Future<Product> authenticate ({
    @required String username,
    @required String password,
  }) async {
    print("UserRepository Authenticate");
    UserLogin userLogin = UserLogin(
        username: username,
        password: password
    );
    Product product = Product(
      id: 0,
      username: username,
      token: token.token,
    );

    mytoken = token.toString();
    print("UserRepo User Constructor");



    return user;
  }



 */