import 'dart:convert';
import 'dart:async';
import 'package:cs308_plaqstore/api_model.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'package:cs308_plaqstore/flutter_api/user_dao.dart';

final _base = "http://10.0.2.2:8000";  //localhost:8000/api/obtain-token/
final _tokenEndpoint = "/api-token-auth/";
final _tokenURL = _base + _tokenEndpoint;


Future<Token> getToken(UserLogin userLogin) async {
  print("Apidart getToken");
  print(_tokenURL);
  final http.Response response = await http.post(Uri.parse(_tokenURL),headers: <String, String>{
    'Content-Type': 'application/json; charset=UTF-8',
  },
    body: jsonEncode(userLogin.toDatabaseJson()),);
  //;
  if (response.statusCode == 200) {
    print("Success_apidart");
    return Token.fromJson(json.decode(response.body));
  } else {
    print(json.decode(response.body).toString());
    throw Exception(json.decode(response.body));
  }
}


