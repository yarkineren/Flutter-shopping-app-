
import 'package:cs308_plaqstore/forms/CustomerProfileForm.dart';
import 'package:cs308_plaqstore/forms/shoppingpageForm.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import 'package:cs308_plaqstore/widgets/HomeScreenTextField.dart';
import 'package:cs308_plaqstore/forms/ProductListPageForm.dart';

import 'package:cs308_plaqstore/widgets/UserLoginTextField.dart';
import 'package:cs308_plaqstore/forms/api_forms.dart';
import 'package:cs308_plaqstore/forms/loginForm.dart';
import 'package:cs308_plaqstore/forms/OrderForm.dart';
import 'package:google_fonts/google_fonts.dart';


//API
class SimpleBlocDelegate extends BlocDelegate{
  @override
  void onEvent(bloc, event){
    super.onEvent(bloc, event);
    print(event);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    super.onTransition(bloc, transition);
    print (transition);
  }

  @override
  void onError(Bloc bloc, Object error, StackTrace stacktrace) {
    super.onError(bloc, error, stacktrace);
  }
}
//API


void main(){
  BlocSupervisor.delegate = SimpleBlocDelegate();
  final userRepository = UserRepository();
  runApp(
      BlocProvider<AuthenticationBloc>(
        create: (context) {
          return AuthenticationBloc(
              userRepository: userRepository
          )..add(AppStarted());
        },
        child: Pwak(userRepository: userRepository),
      )
  );
}

class Pwak extends StatelessWidget{
  final UserRepository userRepository;
  Pwak({Key key, @required this.userRepository}): super(key: key);
  @override
  Widget build(BuildContext context)
  {return MaterialApp(
    theme: ThemeData.light().copyWith(
      textTheme: GoogleFonts.chivoTextTheme(
        Theme.of(context).textTheme,
      )
    ),
    debugShowCheckedModeBanner: false,
    home:
    BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        if (state is AuthenticationUnintialized) {
          return SplashPage();
        }
        if (state is AuthenticationAuthenticated) {
          return shoppingpageForm();
        }
        if (state is AuthenticationUnauthenticated) {
          return LoginPage(userRepository: userRepository,);
        }
        if (state is AuthenticationLoading) {
          return LoadingIndicator();
        }
      },
    ),
  );
  }
}

