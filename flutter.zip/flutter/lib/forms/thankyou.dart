
import 'package:cs308_plaqstore/forms/shoppingpageForm.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThankyouPage extends StatefulWidget {
  ThankyouPage();

  @override
  _ThankyouState createState() => _ThankyouState();
}

class _ThankyouState extends State<ThankyouPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: Text("Thank You :)"),
          backgroundColor: Colors.deepOrange,
        ),
        body: Column(
            children: [
              Image.asset('assets/Creditcardth.jpg'),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  getThanksWidget(context),
                ],
              ),
            ],
          ),
        );
  }
}

Widget getThanksWidget(BuildContext context) {
  return Container(
      width: 300,
    child: MaterialButton(onPressed: () {
      Navigator.of(context).push(MaterialPageRoute(builder: (context)=> shoppingpageForm(),)
      );
    },
        child: Text('Return to homepage', style: TextStyle(
            color: Colors.white, fontWeight: FontWeight.bold),),
        color: Colors.deepOrange),
  );
}

