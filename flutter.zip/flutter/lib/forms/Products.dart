import 'package:cs308_plaqstore/forms/Product_details.dart';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/forms/Product_details_guest';
class ProductListItem extends StatelessWidget {
  final Product pro1;
  ProductListItem({@required this.pro1,
});
  @override


  Widget build(BuildContext context) {
    return Card(
      child: Hero( tag: pro1.albumName,
        child: Material(
          child: InkWell(onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (context) => new ProductDetails(
            //passing values of the product to the productdetail page
            pd:pro1,
          ))),
            child: GridTile(
              footer: Container(
                color: Colors.white70,
                child: ListTile(
                  leading:Text(pro1.albumName, style: TextStyle(fontWeight: FontWeight.bold),),
                  title:Text(pro1.price, style: TextStyle(color: Colors.deepOrange, fontSize: 10.0), ),
                )
              ), child: Image.network('http://10.0.2.2:8000/images/' + pro1.image,fit: BoxFit.cover,)
            )
          )
        )
      )
    );

  }

}
class ProductListItem_guest extends StatelessWidget {
  final Product pro1;
  ProductListItem_guest({@required this.pro1,
  });
  @override


  Widget build(BuildContext context) {
    return Card(
        child: Hero( tag: pro1.albumName,
            child: Material(
                child: InkWell(onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (context) => ProductDetails_guest(
                  //passing values of the product to the productdetail page
                  pd:pro1,
                ))),
                    child: GridTile(
                        footer: Container(
                            color: Colors.white70,
                            child: ListTile(
                              leading:Text(pro1.albumName, style: TextStyle(fontWeight: FontWeight.bold),),
                              title:Text(pro1.price, style: TextStyle(color: Colors.deepOrange, fontSize: 10.0), ),
                            )
                        ), child: Image.network('http://10.0.2.2:8000/images/' + pro1.image,fit: BoxFit.cover,)
                    )
                )
            )
        )
    );

  }

}