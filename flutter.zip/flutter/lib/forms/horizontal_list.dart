import 'dart:convert';

import 'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:cs308_plaqstore/forms/profileForm.dart';
import 'package:flutter/material.dart';

import 'package:cs308_plaqstore/forms/getProByCate.dart';
import 'package:cs308_plaqstore/forms/ProductListPageForm.dart';
import 'package:google_fonts/google_fonts.dart';
import '../globals.dart';
import '../model.dart';
import 'package:http/http.dart' as http;

import 'Products.dart';


class horizontal_list extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50.0,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Categoryondiscount(image_location: 'assets/discount.png',image_caption: 'Discount',),
          Category(image_location: 'assets/pop.png', image_caption: 'Pop',),
          Category(image_location: 'assets/hiphop.png', image_caption: 'Hip Hop',),
          Category(image_location: 'assets/indie.png', image_caption: 'Indie',),
          Category(image_location: 'assets/metal.png', image_caption: 'Metal',),
          Category(image_location: 'assets/jazz.png', image_caption: 'Jazz',),
          Category(image_location: 'assets/r&b.png', image_caption: 'R&B',),
          Category(image_location: 'assets/rock.png', image_caption: 'Rock',),
          Category(image_location: 'assets/elec.png', image_caption: 'Electronic',),

        ],
      ),
    );
  }
}

class Category extends StatelessWidget {
  final String image_location;
  final String image_caption;

  Category({
    this.image_location,
    this.image_caption
  });

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(2.0),
      child: InkWell(onTap: () { Navigator.of(context).push(
          MaterialPageRoute(builder: (context)=> RemoteCategoriesConfig(image_caption)),);},
        child: Container(
          width: 100.0,
          child: ListTile(
            title: Image.asset(image_location,
              width: 100.0,
              height: 30.0,
            ),
            subtitle: Container(
              alignment: Alignment.topCenter ,
              child: Text(image_caption),
            ),
          ),
        ),
      ),);
  }
}

class Categoryondiscount extends StatelessWidget {
  final String image_location;
  final String image_caption;

  Categoryondiscount({
    this.image_location,
    this.image_caption
  });

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(2.0),
      child: InkWell(onTap: () { Navigator.of(context).push(
        MaterialPageRoute(builder: (context)=> discount()),);},
        child: Container(
          width: 100.0,
          child: ListTile(
            title: Image.asset(image_location,
              width: 100.0,
              height: 30.0,
            ),
            subtitle: Container(
              alignment: Alignment.topCenter ,
              child: Text(image_caption),
            ),
          ),
        ),
      ),);
  }
}
class RemoteConfig {
  static final Map<dynamic, String> config = {
    "BASE_URL": "http://10.0.2.2:8000",
    "BASE_PRODUCTS_URL": "/api/products/",
  };
}
//left here

Future<dynamic> _getProductsByCategory() async {
  print("ProductListPageForm getProductsByCategory");
  var response = await http.get(Uri.parse(
      RemoteConfig.config["BASE_URL"] +
          RemoteConfig.config["BASE_PRODUCTS_URL"]
  ),
    headers: {
      "Authorization": RemoteConfig.config[mytoken],
    },
  ).catchError(
        (error) {
      return false;
    },
  );
  return json.decode(response.body);
}

Future<List<Product>> _parseProductsFromResponsedis() async {
  List<Product> productsList = <Product>[];
  List<Product> productsListtoreturn = <Product>[];
  print("ProductListPageForm parseProductsFromResponse");
  var setCustomerID = await UserInfo(globalusername);

  var dataFromResponse = await _getProductsByCategory();

  dataFromResponse.forEach(
        (newProduct) {
      //parse new product's details
      Product product = new Product(
        modelNo: newProduct["model_no"],
        albumName: newProduct["album_name"],
        artistName: newProduct["artist_name"],
        description: newProduct["description"],
        price: newProduct["price"],
        warranty: newProduct["warranty"],
        genre: newProduct["genre"],
        distributor: newProduct["distributor"],
        image: newProduct["image"],
        stock: newProduct["stock"] != null
            ? newProduct["stock"]
            : 0,
        average_rating: newProduct["average_rating"],
        onDiscount: newProduct['onDiscount'],
      );

      print(product);

      productsList.add(product);
    },
  );
  print("ProductListPageForm parseProductsFromResponse returns");
  for(int i=0;i<productsList.length;i++){
    if(productsList[i].onDiscount == true)
      productsListtoreturn.add(productsList[i]);
  }
  return productsListtoreturn;
}
Widget projectWidgetdis() {
  return FutureBuilder(
    future: _parseProductsFromResponsedis(),
    builder: (context, projectSnap) {
      if (projectSnap.connectionState == ConnectionState.none &&
          projectSnap.hasData == null) {
        //print('project snapshot data is: ${projectSnap.data}');
        return Container();
      }
      return GridView.builder(

        itemCount: projectSnap?.data?.length ?? 0,
        gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2),
        itemBuilder: (context, index) {
          Product project = projectSnap.data[index];
          return ProductListItem(
              pro1: project
          );
        },
      );
    },

  );
}
class discount extends StatefulWidget {
  const discount() ;

  @override
  _discountState createState() => _discountState();
}

class _discountState extends State<discount> {
  @override
  Widget build(BuildContext context) {
    return Scaffold( appBar: new AppBar(
      elevation: 0.1,
      backgroundColor: Colors.deepOrange,
      title: Text('PWAK', style: GoogleFonts.chivo(),),
      actions: <Widget> [
        new IconButton(icon: Icon(Icons.search, color: Colors.white,), onPressed:null,),
      ],
    ),
      body:  projectWidgetdis(),
    );
  }
}
