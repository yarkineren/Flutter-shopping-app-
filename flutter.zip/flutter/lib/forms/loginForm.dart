import 'package:cs308_plaqstore/forms/register_form.dart';
import 'package:cs308_plaqstore/forms/shoppingpageForm.dart';
import 'package:flutter/material.dart';
import'package:cs308_plaqstore/widgets/UserLoginTextField.dart';
import'package:cs308_plaqstore/widgets/ForgotPasswordTextField.dart';
import'package:cs308_plaqstore/widgets/HomeScreenTextField.dart';
import'package:cs308_plaqstore/forms/registerForm.dart';
import'package:cs308_plaqstore/flutter_api/user_repository.dart';
import'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import 'package:cs308_plaqstore/forms/ShoppingpageGuestForm.dart';

import 'dart:async';
import'package:cs308_plaqstore/flutter_api/bloc/login_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:google_fonts/google_fonts.dart';

  // HALA ÇALIŞILIYOR
    class UserFieldValidator {
      static String validate(String value) {
        return value.isEmpty  ? 'username can\'t be empty': null;
      }
    }

    class UserVFieldValidator {
      static String validate(String value) {
        return value.isNotEmpty  ? 'username is valid ?': null;
      }
    }

    class UserIFieldValidator {
      static String validate(String value) {
        return value.isNotEmpty  ? 'username is invalid ?': null;
      }
    }

    class PasswordFieldValidator {
      static String validate(String value) {
        return value.isEmpty  ? 'password can\'t be empty': null;
      }
    }

    class PasswordVFieldValidator {
      static String validate(String value) {
       return value.isNotEmpty  ? 'password is valid ?': null;
      }
    }

    class PasswordIFieldValidator {
      static String validate(String value) {
        return value.isNotEmpty  ? 'password is invalid ?': null;
      }
    }

    class EmailFieldValidator {
      static String validate(String value) {
        return value.isEmpty  ? 'e-mail can\'t be empty': null;
     }
    }

    class EmailVFieldValidator {
      static String validate(String value) {
        return value.isNotEmpty  ? 'e-mail is valid': null;
      }
    }

    class EmailIFieldValidator {
      static String validate(String value) {
        return value.isNotEmpty  ? 'e-mail is invalid': null;
      }
    }

//
// String emailValid(String mail, int type){
//   bool request = true; // To be removed after connecting to backend
//   bool mailCheck = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(mail);
//   if(!mailCheck){
//     return "Please enter a valid e-mail address";
//   }
//   // send request -> bool feedback = request(mail,1); // will return true or false
//   if(request)
//     return null;
//   else
//     return "This e-mail address is not registered";
//
// }


class LoginPage extends StatelessWidget {
  final UserRepository userRepository;

  LoginPage({Key key, @required this.userRepository})
      : assert(userRepository != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Welcome to Pwak', style: GoogleFonts.chivo(),),
        backgroundColor: Colors.deepOrange,
      ),
      body: BlocProvider(
        create: (context) {
          return LoginBloc(
            authenticationBloc: BlocProvider.of<AuthenticationBloc>(context),
            userRepository: userRepository,
          );
        },
        child: LoginForm(),
      ),
    );
  }
}





class LoginForm extends StatefulWidget{
  @override
  State<StatefulWidget> createState()
  {
    return Login();
  }
}

class Login extends State<LoginForm> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _onLoginButtonPressed() {
      print(_usernameController.text);
      BlocProvider.of<LoginBloc>(context).add(LoginButtonPressed(
        username: _usernameController.text,
        password: _passwordController.text,
      ));
    }

    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state is LoginFaliure) {
          Scaffold.of(context).showSnackBar(SnackBar(
            content: Text('${state.error}'),
            backgroundColor: Colors.red,
          ));
        }
      },
      child: BlocBuilder<LoginBloc, LoginState>(
        builder: (context, state) {
          return Container(
            child: Form(
              child: Padding(
                padding: EdgeInsets.all(40.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    TextFormField(
                      decoration: InputDecoration(
                          labelText: 'username', icon: Icon(Icons.person)),

                     // BURASI HALA DENENİYOR
                     // validator: (value) {
                      //  String message = UserFieldValidator.validate(value);
                      //if(message != null){
                      //   return message;
                      // }
                      //  else {
                      //    return null;
                      //  }},

                      controller: _usernameController,
                      //onSaved: (value) { _usernameController.text = value;},
                    ),
                    TextFormField(
                      decoration: InputDecoration(
                          labelText: 'password', icon: Icon(Icons.security)),
                      controller: _passwordController,
                      obscureText: true,
                     //validator: (value) => value.isEmpty ? 'password can\'t be empty': null,
                     // onSaved: (value) => password = value,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.55,
                      height: MediaQuery.of(context).size.width * 0.22,
                      child: Padding(
                        padding: EdgeInsets.only(top: 30.0),
                        child: RaisedButton(
                          onPressed: state is! LoginLoading
                              ? _onLoginButtonPressed
                              : null,
                          child: Text(
                            'Login',
                            style: TextStyle(
                              fontSize: 24.0,
                            ),
                          ),
                          shape: StadiumBorder(
                            side: BorderSide(
                              color: Colors.black,
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.55,
                      height: MediaQuery.of(context).size.width * 0.22,
                      child: Padding(
                        padding: EdgeInsets.only(top: 30.0),
                        child: RaisedButton(
                          onPressed:() {Navigator.push(context, MaterialPageRoute(builder: (context) => register_form()),);},
                          child: Text(
                            'Register',
                            style: TextStyle(
                              fontSize: 24.0,
                            ),
                          ),
                          shape: StadiumBorder(
                            side: BorderSide(
                              color: Colors.black,
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.55,
                      height: MediaQuery.of(context).size.width * 0.22,
                      child: Padding(
                        padding: EdgeInsets.only(top: 30.0),
                        child: RaisedButton(
                          onPressed:() {Navigator.push(context, MaterialPageRoute(builder: (context) => ShoppingpageGuestForm()),);},
                          child: Text(
                            'Guest',
                            style: TextStyle(
                              fontSize: 24.0,
                            ),
                          ),
                          shape: StadiumBorder(
                            side: BorderSide(
                              color: Colors.black,
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      child: state is LoginLoading
                          ? CircularProgressIndicator()
                          : null,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}



