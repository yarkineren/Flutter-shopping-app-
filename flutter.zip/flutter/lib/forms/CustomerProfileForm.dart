import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/widgets/CustomerProfileTextField.dart';
import 'package:cs308_plaqstore/widgets/Customer_ReviewCard.dart';

class CustomerProfileForm extends StatefulWidget{
  @override
  State<StatefulWidget> createState()
  {
    return CustomerProfile();
  }
}

class CustomerProfile extends State<CustomerProfileForm>
{
  List<Customer_Review> reviews = [
    Customer_Review(text: 'I liek it', date: '15 June', likes: 30, comments: 15)
  ];

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: AppBar(
        title:Text('My Profile', style: TextStyle(
          color: AppColors.textColor,
        ),
        ),
        centerTitle: true,
        backgroundColor: AppColors.primary,
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(20.0, 24.0, 20.0, 0.0),
        child: Column(
          children: <Widget>[
            //HEADER
            Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
            CircleAvatar(backgroundImage: AssetImage('assets/user-iconset.png'),
              radius: 60.0,
            ),

            SizedBox(width: 8,),

            Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          //our variables here
          children: <Widget> [

            Text('MY USERNAME', style: TextStyle(color: AppColors.textColor)),
            Row(
              children: <Widget> [
                Icon(
                  Icons.email,
                  color: AppColors.primary,
                ),
                Text('MY E-MAIL', style: TextStyle(color: AppColors.textColor)),
              ],
            ),
          ],
        ),
      ],
            ),
            //DIVIDER
            Divider(
              color: AppColors.primary,
              height : 30,
              thickness: 2.0,
            ),
            //BUTTONS

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                    flex: 1,
                child: Column(
                  children: <Widget>[
                    Customer_MyOrdersButton(onPressed:(){}),
                  ],
                ),
                ),

        Expanded(
          flex: 1,
          child:
                Column(
                  children: <Widget>[
                  Customer_ReviewsButton(onPressed:(){}),
                  ]
                ),
        ),
        Expanded(
          flex: 1,
          child:
                Column(
                    children: <Widget>[
                      Customer_SettingsButton(onPressed:(){}),
                    ]
                ),
        ),
  ]
                ),



            Divider(
              color: AppColors.primary,
              height : 30,
              thickness: 2.0,
            ),
            //REVIEWS
            Column(
            children: reviews.map((review) => Customer_ReviewCard(review: review)).toList(),
            ),

        ],
      ),
      )
    );
  }
}

