import 'package:flutter/cupertino.dart';
//import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:flutter/material.dart';

import 'checkout.dart';
class cart extends StatefulWidget{
  final List<Product> Cartlist;
  cart(this.Cartlist);
  @override
  _CartAppState createState() => _CartAppState(this.Cartlist);

}
class _CartAppState extends State<cart>{
  _CartAppState(this.Cartlist);
  List<Product> Cartlist;
  int sum = 0;
  int calculateSum() {
    setState(() {
      int sums=0;
      for (int i=0;i<Cartlist.length;i++)
      {
        int num = int.parse(Cartlist[i].price);
        sums=  num + sums;
      }
      return sums;

    });

  }
  void Initstate(){
    super.initState();
    sum=calculateSum();
  }

  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: new AppBar(
       elevation: 0.1,
       backgroundColor: Colors.deepOrange,
       title: Text('MY CART'),
     ),
     body: ListView.builder(
         itemCount: Cartlist.length,
         itemBuilder: (context, index){
           var item =Cartlist[index];
           return Padding(
             padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
             child: Card(
               elevation: 4.0,
               child: ListTile(
                 leading: Image.network('http://10.0.2.2:8000/images/' + item.image,fit: BoxFit.cover,),
                 title: Text(item.albumName),
                 trailing: GestureDetector(
                   child: Icon(
                     Icons.remove_circle,
                     color: Colors.red,
                   ),
                   onTap: (){
                     setState(() {
                       Cartlist.remove(item);
                     });
                 }
                 ),
               ),
             ),

           );
         }
     ),
     bottomNavigationBar: new Container(
       color: Colors.white,
       child: Row(
         children: <Widget>[
           Expanded(child: ListTile(
             title: new Text('Total:'),
             subtitle: Text('\$${Cartlist.length > 0 ? Cartlist.map<double>((m) => double.parse(m.price)).reduce((value, element) => value + element).toStringAsFixed(2) : 0}'),
           )),
           Expanded(
             child: MaterialButton(onPressed: () async{
               await showDialog(
                 context: context,
                 builder: (context) => new AlertDialog(
                   backgroundColor: Colors.deepOrange,
                   title: new Text('You have to login to buy products'),

                   actions: <Widget>[
                     new FlatButton(
                       onPressed: () {
                         int count = 0;
                         Navigator.popUntil(context, (route) {
                           return count++ == 3;
                         }); //burada da anaysayfaya gitmem lazım
                       },
                       child: new Text('Login',),
                     ),
                   ],
                 ),
               );


             },
             child: Text('Check Out',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold ),),
             color: Colors.deepOrange),
           ),
         ],
       )
     ),
   );
  }

}