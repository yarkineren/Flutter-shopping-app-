import 'package:cs308_plaqstore/model.dart';
import 'package:flutter/cupertino.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cs308_plaqstore/globals.dart' as globals;
import 'dart:async';
import 'package:email_validator/email_validator.dart';

import 'dart:convert';

import 'package:http/http.dart';

import 'loginForm.dart';

Future<int> Register_User(Register user, BuildContext context) async
{
  String base = "http://10.0.2.2:8000/api/users/";

  var user_value = user.toJson();
  var user_data = json.encode(user_value);

  print(user_data);


  final response = await http.post(Uri.parse(base),
      headers: <String, String>
      {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: user_data
  );

  print(response.statusCode);
  return response.statusCode;
}

class register_form extends StatefulWidget {
  const register_form({Key key}) : super(key: key);

  @override
  _register_formState createState() => _register_formState();
}

showAlertRegister(BuildContext context) {

  // set up the button
  Widget okButton = FlatButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.pop(context);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Sorry!"),
    content: Text("We can't register you now. Please try again later."),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

class _register_formState extends State<register_form> {
  final _RegformKey = GlobalKey<FormState>();
  bool _obscureText = true;
  var myForm = Register();
  @override
  Form regForm(){
    return Form(
      autovalidateMode: AutovalidateMode.onUserInteraction, key: _RegformKey,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text("You are one step closer.",
                style: Theme.of(context).textTheme.headline6),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return ' must not be empty.';
                      }
                      return null;
                    },
                    onChanged: (String value) {
                      myForm.first_name = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "name",
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return ' must not be empty.';
                      }
                      return null;
                    },
                    onChanged: (String value) {
                      myForm.last_name = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Surname",
                    ),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 300,
                child: TextFormField(
                  validator: (value) {
                    if (!EmailValidator.validate(value)) {
                      return 'Please enter a legit e-mail';
                    }
                    return null;
                  },
                  onChanged: (String value) {
                   myForm.email= value;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "e-mail",
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 300,
                child: TextFormField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return ' must not be empty.';
                    }
                    return null;
                  },
                  onChanged: (String value) {
                    myForm.username = value;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Username",
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 300,
                child: TextFormField(
                  obscureText: _obscureText,
                  validator: (value) {
                    if (value.isEmpty) {
                      return ' must not be empty.';
                    }
                    return null;
                  },
                  onChanged: (String value) {
                   myForm.password = value;
                  },

                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Password",
                    suffixIcon: new GestureDetector(
                      onTap: () {
                        setState(() {
                          _obscureText = !_obscureText;
                        });
                      },
                      child:
                      new Icon(_obscureText ? Icons.visibility : Icons.visibility_off),
                    ),

                  ),

                ),
              ),
            ),
          ]),
    );

}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        bottomNavigationBar:  BottomAppBar(
          child: MaterialButton(
              onPressed: () async {
                if (_RegformKey.currentState.validate()) {
                  //burda yaparsın işini
                  int response = await Register_User(myForm, context);
                  Navigator.pop(context);
                }
              },
              child: Text(
                'Register',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              color: Colors.deepOrange),
        ),
        appBar: AppBar(
          title: Text("Register"),
          backgroundColor: Colors.deepOrange,
        ),
        body: SingleChildScrollView(
          reverse: true,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 300),
            child: Column(
              children: <Widget>[
                regForm(),


              ],

            ),
          ),
        ));
  }
}
