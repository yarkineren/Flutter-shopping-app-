import 'package:cs308_plaqstore/forms/Products.dart';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/widgets/ProductListItemTextField.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:convert';
import 'dart:async';
//import 'package:cs308_plaqstore/product_model.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'package:cs308_plaqstore/flutter_api/user_dao.dart';
import 'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/forms/cart.dart';

import 'package:cs308_plaqstore/flutter_api/api.dart';

class RemoteCategoriesConfig extends StatefulWidget {
  String Category;
  RemoteCategoriesConfig(this.Category);
  @override
  CateState createState() => CateState(this.Category);
}
class CateState extends State<RemoteCategoriesConfig> {
  CateState(this.Category);
  String Category;

  Uri getProductCategories(String categoryname) =>
      Uri.parse(
          'http://10.0.2.2:8000/api/product-search/?genre=' + categoryname);

  Future<dynamic> searchCategories(String categoryname) async {
    final uri = getProductCategories(categoryname);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }

  Future<List<Product>> _parseProductsFromResponseCate(
      String categoryname) async {
    List<Product> productsList = <Product>[];
    print("ProductListPageForm parseProductsFromResponse");

    var dataFromResponse = await searchCategories(categoryname);

    dataFromResponse.forEach(
          (newProduct) {
        //parse new product's details
        Product product = new Product(
          modelNo: newProduct["model_no"],
          albumName: newProduct["album_name"],
          description: newProduct["description"],
          price: newProduct["price"],
          warranty: newProduct["warrantry"],
          genre: newProduct["genre"],
          image: newProduct["image"],
          distributor: newProduct["distributor"],
          stock: newProduct["stock"] != null
              ? newProduct["stock"]
              : 0,
          //images: imagesOfProductList,
        );

        print(product);

        productsList.add(product);
      },
    );
    return productsList;
  }

  Widget projectWidgetCate(String Cate) {
    return FutureBuilder(
      future: _parseProductsFromResponseCate(Cate),
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.none &&
            projectSnap.hasData == null) {
          //print('project snapshot data is: ${projectSnap.data}');
          return Container();
        }
        return GridView.builder(

          itemCount: projectSnap?.data?.length ?? 0,
          gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2),
          itemBuilder: (context, index) {
            Product project = projectSnap.data[index];
            return ProductListItem(
              pro1: project
            );
          },
        );
      },

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold( appBar: new AppBar(
      elevation: 0.1,
      backgroundColor: Colors.deepOrange,
      title: Text('PWAK', style: GoogleFonts.chivo(),),
      actions: <Widget> [
        new IconButton(icon: Icon(Icons.search, color: Colors.white,), onPressed:null,),
      ],
    ),
      body:  projectWidgetCate(Category),
    );
  }

}
