import 'dart:async';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/forms/product_details.dart';



//http://127.0.0.1:8000/api/order-item/?customer=7
Uri getUser(int customer_id) =>
    Uri.parse(
        'http://10.0.2.2:8000/api/order-item/?order=' + customer_id.toString());

Future<dynamic> searchUser(int customer_id) async {
  final uri = getUser(customer_id);
  final response = await http.get(uri);
  if (response.statusCode == 200)
    return json.decode(response.body);
}

Future<List<OrderItem>> _parseItems(int customer_id) async {
  List<OrderItem> AllItemList = <OrderItem>[]; //all item list will be user's orders' items, without further filtration
  print("Orderform parseUser");

  var dataFromResponse = await searchUser(customer_id);

  dataFromResponse.forEach((Item){
    OrderItem order_item = new OrderItem.fromJson(Item);
    AllItemList.add(order_item);
    print(order_item.dateAdded);
  });

  return AllItemList;
}

Future<List<OrderItem>> get_shoppingCartItems(int customer_id) async { //from all items, isComplete = false items is chosen
  List list = await _parseItems(customer_id); //submit customer id as global variable
  List<OrderItem> shoppingCartItems = <OrderItem>[];

  for(var i=0; i<list.length; i++)
    {
      if(list[i].order.isComplete == false)
        {
          shoppingCartItems.add(list[i]);
          print(list[i].quantity.toString()); //returns quantity of the order item
          print(list[i].product.albumName);  //returns album name of the product -> order item
          print(list[i].order.orderDate.toString()); //returns order date of the order item
        }
    }

  return shoppingCartItems;

}
Future<List<OrderItem>> get_purchasedItems(int customer_id) async { //from all items, isComplete = true items is chosen
  List list = await _parseItems(customer_id); //submit customer id as global variable
  List<OrderItem> purchasedItems = <OrderItem>[];

  for(var i=0; i<list.length; i++)
  {
    if(list[i].order.isComplete == true)
    {
      purchasedItems.add(list[i]);
      print(list[i].quantity.toString());
    }
  }
  return purchasedItems;
}

//WIDGET IS USED FOR DEBUG API, DELETE THIS IF YOU WANT, LINE 48-50 SHOWS HOW TO REACH ATTRIBUTES
class OrderItemListPage extends StatelessWidget {
  BuildContext context;

  @override
  Widget build(BuildContext context) {
    this.context = context;

    return Scaffold(
      body: projectWidget(),
    );
  }

  Widget projectWidget() {
    return FutureBuilder(
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.none &&
            projectSnap.hasData == null) {
          //print('project snapshot data is: ${projectSnap.data}');
          return Container();
        }
        return GridView.builder(

          itemCount: projectSnap?.data?.length ?? 0,
          gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          itemBuilder: (context, index) {
            OrderItem project = projectSnap.data[index];
            return OrderListItem(
              pro1: project,
            );
          },
        );
      },
      future: get_shoppingCartItems(global_customer_id),
    );
  }
}


class OrderListItem extends StatelessWidget {
  final OrderItem pro1;
  OrderListItem({@required this.pro1,
  });
  @override


  Widget build(BuildContext context) {
    return Card(
        child: Hero( tag: pro1.product,
            child: Material(
                child: InkWell(onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (context) => new OrderItemDetails(
                  pd:pro1,
                ))),
                )
            )
        )
    );

  }

}

class OrderItemDetails extends StatefulWidget{
  final OrderItem pd;
  OrderItemDetails({this.pd});
  @override
  _OrderItemDetailsState createState() => _OrderItemDetailsState();
}
class _OrderItemDetailsState extends State<OrderItemDetails>{
  @override
  Widget build(BuildContext context){
    return Scaffold(
        appBar: new AppBar(
          elevation: 0.1,
          backgroundColor: Colors.deepOrange,
          title: Text('PWAK', style: GoogleFonts.chivo(),),
          actions: <Widget> [
            new IconButton(icon: Icon(Icons.search, color: Colors.white,), onPressed:null,),
          ],
        ),
        body: new ListView(
            children: <Widget>[
              new Container(
                  height:300.0,
                  child: GridTile(
                    footer: new Container(
                      color: Colors.white70,
                      child: ListTile(
                        leading: new Text(widget.pd.dateAdded, style: TextStyle(fontWeight: FontWeight.bold),),//leading is left
                        title: new Row(
                          children: <Widget>[
                            Expanded(child: new Text(widget.pd.quantity.toString()))
                          ],
                        ),

                      ),
                    ),
                  )// in this part we will have a image when we get from the api
              ),
              //Buraya description-stock...
              Row(
                children: <Widget>[
                  new IconButton(icon: Icon(Icons.add_shopping_cart,color: Colors.red,), onPressed: (){})
                ],
              ),
            ]
        )
    );
  }
}