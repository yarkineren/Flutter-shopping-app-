import 'dart:async';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/forms/product_details.dart';
import 'package:cs308_plaqstore/forms/checkout.dart';
import 'package:cs308_plaqstore/forms/cartwithapi.dart';

import 'checkout.dart';


class cartwithapilist extends StatefulWidget{
  @override
  _CartAppState createState() => _CartAppState();

}
class _CartAppState extends State<cartwithapilist>{
  _CartAppState();
  Uri getUser(int customer_id) =>
      Uri.parse(
          'http://10.0.2.2:8000/api/order-item/?order=' +
              customer_id.toString());

  Future<dynamic> searchUser(int customer_id) async {
    final uri = getUser(customer_id);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }

  Future<List<OrderItem>> _parseItems(int customer_id) async {
    List<OrderItem> AllItemList = <OrderItem>[
    ]; //all item list will be user's orders' items, without further filtration
    print("Orderform parseUser");

    var dataFromResponse = await searchUser(customer_id);

    dataFromResponse.forEach((Item) {
      OrderItem order_item = new OrderItem.fromJson(Item);
      AllItemList.add(order_item);
      print(order_item.dateAdded);
    });

    return AllItemList;
  }


  Future<List<OrderItem>> get_shoppingCartItems(int customer_id) async {
    //from all items, isComplete = false items is chosen
    List list = await _parseItems(
        customer_id); //submit customer id as global variable
    List<OrderItem> shoppingCartItems = <OrderItem>[];
    global_sum=0;
    for (var i = 0; i < list.length; i++) {
      if (list[i].order.isComplete == false) {
        global_sum= global_sum + double.parse(list[i].product.price);
        shoppingCartItems.add(list[i]);
        print(list[i].quantity.toString()); //returns quantity of the order item
        print(list[i].product
            .albumName); //returns album name of the product -> order item
        print(list[i].order.orderDate
            .toString());//returns order date of the order item

      }
    }

    return shoppingCartItems;
  }
  Widget projectWidgetCartlist() {
    return FutureBuilder(
      future: get_shoppingCartItems(global_customer_id),
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.waiting &&
            projectSnap.hasData == null) {
          return Container();
        }
        else if(projectSnap.connectionState == ConnectionState.done && projectSnap.hasData == true){
          return  carty(
              projectSnap.data
          );
        }
        return Container();

      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return projectWidgetCartlist();
  }

}
class carty extends StatefulWidget{
  final List<OrderItem> Cartlist;
  carty(this.Cartlist);
  @override
  _CartAppStatey createState() => _CartAppStatey(this.Cartlist);

}
class _CartAppStatey extends State<carty> {
  _CartAppStatey(this.Cartlist);
  Future<http.Response> delete(OrderItem) async{
    Uri delete_this_url = Uri.parse('http://10.0.2.2:8000/api/order-item/' + OrderItem.id.toString() + '/');
    final http.Response response = await http.delete(delete_this_url,
      headers: <String, String> {
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );
    return response;
  }
  Future<http.Response> ChangeQuantityCartApi(OrderItem oi, String message) async
  {
    String base = "http://10.0.2.2:8000/api/order-item/";

    OrderItem _orderItem = new OrderItem();
    _orderItem = oi;
    var orderitem_value = _orderItem.toJson();
    var event = {};
    var message_type = message;
    event["message_type"] = message_type;
    event ["event"] = orderitem_value;
    var orderitem_data = json.encode(event);


    //object = {event: JSON.parse(orderitem_data)};

    print(orderitem_data);

    final response = await http.post(Uri.parse(base),
        headers: <String, String>
        {
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: orderitem_data
    );
    print(response);
    return response;
  }
  List<OrderItem> Cartlist;

  Widget build(context) {
    delete_local(item){
      setState(() {
        if(item.quantity == 1)
          {
            Cartlist.remove(item);
            delete(item);
          }
        else{
          item.quantity =  item.quantity - 1;
          ChangeQuantityCartApi(item, "ChangeQuantity");
        }
      });
    }

    return Scaffold(
      appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.deepOrange,
        title: Text('MY CART'),
      ),
      body: ListView.builder(
          itemCount: Cartlist.length,
          itemBuilder: (context, index) {
            OrderItem item = Cartlist[index];
            return Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 8.0, vertical: 2.0),
              child: Card(
                elevation: 4.0,
                child: ListTile(
                  leading: Image.network(
                    'http://10.0.2.2:8000/images/' + item.product.image,
                    fit: BoxFit.cover,),
                  title: Text(item.product.albumName),
                  trailing: Wrap(
                      spacing: 12,
                      children: <Widget>[
                        Text('quantity ' + item.quantity.toString()),
                        GestureDetector(
                            child: Icon(
                              Icons.remove_circle,
                              color: Colors.red,
                            ),
                            onTap: (){
                              delete_local(item);
                              delete(item);//burada fonksiyon
                            }

                        ),

                      ]
                  ),
                ),
              ),

            );
          }
      ),
      bottomNavigationBar: new Container(
          color: Colors.white,
          child: Row(
            children: <Widget>[
              Expanded(child: ListTile(
                title: new Text('Total:'),
                subtitle: Text('\$${Cartlist.length > 0 ? Cartlist.map<double>((m) => double.parse(m.product.price )* m.quantity).reduce((value, element) => value + element).toStringAsFixed(2) : 0}'),
              )),
              Expanded(
                child: MaterialButton(onPressed: () {
                  if(Cartlist.isNotEmpty){
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context)=> CheckoutPage(Cartlist),)
                );}},
                    child: Text('Check Out', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),),
                    color: Colors.deepOrange),
              ),
            ],
          )
      ),
    );
  }
}