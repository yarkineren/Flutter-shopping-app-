import 'package:cs308_plaqstore/forms/OrderForm.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
//import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/forms/comments.dart';
import 'package:cs308_plaqstore/widgets/rating.dart';
import 'package:cs308_plaqstore/globals.dart' as globals;
import 'package:google_fonts/google_fonts.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

Future<void> addToCartApi(Product pd) async //call only when new order is generated
{
  List<OrderItem> cart;
  cart = await get_shoppingCartItems(globals.global_customer_id);
  for(int i=0;i<cart.length;i++)
    {
      if(cart[i].product.albumName == pd.albumName)
        {
          cart[i].quantity++;
          ChangeQuantityCartApi(cart[i], "ChangeQuantity");
          return;
        }
    }

  String base = "http://10.0.2.2:8000/api/order-item/";

  OrderItem _orderItem = new OrderItem();
  _orderItem.product = pd;
  //_orderItem.event.message_type = "NewOrderItem";

  Order _order = new Order();
  //_order.isComplete = false; MIGHT NOT BE NEEDED NOW, CHECK
  _order.transactionId = "12345";
  Customer _customer = new Customer();
  _customer.username = globals.globalusername;
  _order.customer = _customer;
  _orderItem.order = _order;
  //_orderItem.order.customer.username = globals.globalusername;
  _orderItem.quantity = 1;
  //_orderItem.event = _orderItem;

  var orderitem_value = _orderItem.toJson();
  var event = {};
  var message_type = "NewOrderItem";
  event["message_type"] = message_type;
  event ["event"] = orderitem_value;
  var orderitem_data = json.encode(event);


  //object = {event: JSON.parse(orderitem_data)};

  print(orderitem_data);

  final response = await http.post(Uri.parse(base),
  headers: <String, String>
  {
    'Content-Type': 'application/json; charset=UTF-8',
  },
    body: orderitem_data
  );
  print(response);
  return;
}

Future<http.Response> ChangeQuantityCartApi(OrderItem oi, String message) async //when product already exists, increase its quantity
{

  String base = "http://10.0.2.2:8000/api/order-item/";
  OrderItem _orderItem = new OrderItem();
  _orderItem = oi;
  var orderitem_value = _orderItem.toJson();
  var event = {};
  var message_type = message;
  event["message_type"] = message_type;
  event ["event"] = orderitem_value;
  var orderitem_data = json.encode(event);

  print(orderitem_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>
      {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: orderitem_data
  );
  print(response);
  return response;
}


class ProductDetails extends StatefulWidget{
  final Product pd;

  ProductDetails({this.pd});
  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}
class _ProductDetailsState extends State<ProductDetails>{
  @override
  Widget build(BuildContext context){
    if(widget.pd.average_rating == null){
      widget.pd.average_rating = 0;
    }
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.deepOrange,
        title: Text('PWAK', style: GoogleFonts.chivo(),),
        actions: <Widget> [
          new IconButton(icon: Icon(Icons.search, color: Colors.white,), onPressed:null,),
        ],
      ),
      body: new ListView(
        children: <Widget>[
          new Container(
            height:300.0,
            child: GridTile(
              child: Container(
                color: Colors.white,
                  child: Image.network('http://10.0.2.2:8000/images/' + widget.pd.image,fit: BoxFit.cover,)
              ),
              footer: new Container(
                color: Colors.white70,
                child: ListTile(
                  leading: new Text(widget.pd.albumName, style: TextStyle(fontWeight: FontWeight.bold),),//leading is left
                  title: new Row(
                    children: <Widget>[
                      Expanded(child: new Text(widget.pd.modelNo))
                    ],
                  ),
                ),
              ),
            )// in this part we will have a image when we get from the api
          ),

          Row(
            children: <Widget>[
              Expanded(
                child: MaterialButton(onPressed: () { //POST OPERATION
                  setState(() {
                    if(int.parse(widget.pd.stock) > 0 )
                      {
                        addToCartApi(widget.pd); //
                        print("Product Details Future Order Item Returns");
                      }

                  });
                  globals.Mycart.add(widget.pd);
                },
                  color: Colors.red,
                  textColor: Colors.white,
                  elevation: 0.2,
                  child: new Text('Add to Cart'),
                ),
              ),
              new IconButton(icon: Icon(Icons.add_shopping_cart,color: Colors.red,), onPressed: (){})
            ],
          ),


         Padding(
           padding:  EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
           child: new StarRating(
              rating: widget.pd.average_rating,
           color: Colors.deepOrange),
         ),
          //CommentBuilder(widget.pd.albumName),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
              child: Container(
                color: Colors.white,
              //decoration: BoxDecoration(

                //border: Border.all(width: 3,color: Colors.red,),
                  //  borderRadius: const BorderRadius.all(const Radius.circular(8))
              //),
              child: Text.rich(
              TextSpan(
                text: '\u{1F4C0}:', // default text style
                children: <TextSpan>[
                  TextSpan(text: widget.pd.albumName, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F3A4}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.artistName, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F3BC}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.genre, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F4D6}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.description, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F4B2}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.price, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F4E6}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.stock, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F69A}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.distributor, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\u{1F4DD}:", style: TextStyle(fontStyle: FontStyle.italic,fontWeight: FontWeight.bold)),
                  TextSpan(text: widget.pd.warranty, style: TextStyle(fontStyle: FontStyle.italic)),

                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),
                  TextSpan(text: "\n", style: TextStyle(fontStyle: FontStyle.italic)),

                ],
              ),
          ),
            ),
          //Buraya description-stock...
          //CommentBuilder(widget.pd.albumName),
            ),
          CommentBuilder(widget.pd.albumName),
        ]
    )

    );
  }
}

