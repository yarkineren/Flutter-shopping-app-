import 'dart:async';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/widgets/rating.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cs308_plaqstore/forms/product_details.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:quick_feedback/quick_feedback.dart';

import 'comments.dart';

class OldOrders extends StatefulWidget {
  @override
  Oldies createState() => Oldies();
}

showAlertDialogRefundFail(BuildContext context) {
  // set up the button
  Widget okButton = FlatButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.pop(context);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Sorry!"),
    content:
    Text("Our refund policy accepts refunds within 30 days."),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

showAlertDialogRefundSuccess(BuildContext context) {
  // set up the button
  Widget okButton = FlatButton(
    child: Text("OK"),
    onPressed: () {
      Navigator.pop(context);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Success"),
    content:
    Text("Your refund request is created."),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

Future<dynamic> GetRefundInformation(OrderItem oi) async
{
  String base = "http://10.0.2.2:8000/api/refunds/?order_item="+oi.id.toString();
  Uri request_url = Uri.parse(base);
  final response = await http.get(request_url);
  if (response.statusCode == 200)
    return json.decode(response.body);
}
Future<Refund> parseRefundInformation(OrderItem oi) async {
  List<Refund> AllItemList = <Refund>[];
  List<Refund> AllItemListReturn = <Refund>[];

  print("Refund getRefundInfo");

  var dataFromResponse = await GetRefundInformation(oi);
  dataFromResponse.forEach((Item) {
    Refund order_item = new Refund.fromJson(Item);
    AllItemList.add(order_item);
  });

  if(AllItemList.isEmpty == true){
    Refund order_item = new Refund();
    order_item.approval = 0;
    AllItemList.add(order_item);
  }
  for(int i=0; i<AllItemList.length; i++)
    {
      if(AllItemList[i].approval != null)
        {
          AllItemListReturn.add(AllItemList[i]);
        }
    }
  return AllItemList[0];
}

@override
Widget projectWidgetRefund(OrderItem oi) {
  return FutureBuilder(
    builder: (context, projectSnap) {
      if (projectSnap.hasData == null) {
        //print('project snapshot data is: ${projectSnap.data}');
        return Container();
      }
      else if(projectSnap.hasData != null)
        {
          if(projectSnap.data.approval == 1){
            return Text( "Your refund request is pending" ,style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold));
          }
          else if(projectSnap.data.approval == 2){
            return Text( "Your refund request is approved" ,style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold));
          }
          else if(projectSnap.data.approval == 3){
            return Text( "Your refund request is disapproved" ,style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold));
          }
          else{
            return Text( "" ,style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold));
          }
      }
      else{
        return Container();
      }
    },
    future: parseRefundInformation(oi),
  );
}



Future<http.Response> GiveRatingApi(OrderItem oi, String message) async
{
  String base = "http://10.0.2.2:8000/api/order-item/";

  OrderItem _orderItem = new OrderItem();
  _orderItem = oi;
  var orderitem_value = _orderItem.toJson();
  var event = {};
  var message_type = message;
  event["message_type"] = message_type;
  event ["event"] = orderitem_value;
  var orderitem_data = json.encode(event);

  print(orderitem_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>
      {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: orderitem_data
  );
  print(response);
  return response;
}

Future<http.Response> AskRefundApi(OrderItem oi) async
{
  //accept based on oi.order.date
  String base = "http://10.0.2.2:8000/api/refunds/";

  OrderItem refund_order_item = new OrderItem();
  refund_order_item = oi;
  var orderitem_value = refund_order_item.toJson();
  var event = {};
  var order_item = {};
  order_item['order_item'] = orderitem_value;
  event ["event"] = order_item;
  event ["request_date"] = DateTime.now().toString();
  event ["onDiscount"] = false;
  event ["price"] = oi.product.price;
  event ["quantity"] = oi.quantity;
  event ["total"] = oi.product.price * oi.quantity;

  //Refund a = new Refund();
  //a.orderItemId = oi;
  //a.requestDate = DateTime.now().toString();
  //a.total = (oi.product.price * oi.quantity) as double; //burda bi yerde sorun
  //a.quantity = (oi.quantity) as double;
  //a.onDiscount = false;
  //a.price = oi.product.price;
  var refund_data = json.encode(event);

  print(refund_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>
      {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: refund_data
  );
  print(response.statusCode);
  return response;
}


Future<http.Response> AddCommentApi(OrderItem oi, String message) async
{
  String base = "http://10.0.2.2:8000/api/comments/";

  Product commented_product = new Product();
  commented_product = oi.product;
  Customer _customer = new Customer();
  _customer.username = globalusername;
  comment a = new comment();
  a.product = commented_product;
  a.user = _customer;
  a.approval = 1;
  a.body = message;


  var comment_value = a.toJson();
  var event = {};
  event ["event"] = comment_value;
  var comment_data = json.encode(event);

  print(comment_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>
      {
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: comment_data
  );
  print(response);
  return response;
}

class Oldies extends State<OldOrders> {


//http://127.0.0.1:8000/api/order-item/?customer=7
  Uri getUser(int customer_id) =>
      Uri.parse(
          'http://10.0.2.2:8000/api/order-item/?order=' +
              customer_id.toString());

  Future<dynamic> searchUser(int customer_id) async {
    final uri = getUser(customer_id);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }

  Future<List<OrderItem>> _parseItems(int customer_id) async {
    List<OrderItem> AllItemList = <OrderItem>[
    ]; //all item list will be user's orders' items, without further filtration
    print("Orderform parseUser");

    var dataFromResponse = await searchUser(customer_id);

    dataFromResponse.forEach((Item) {
      OrderItem order_item = new OrderItem.fromJson(Item);
      AllItemList.add(order_item);
      print(order_item.dateAdded);
    });

    return AllItemList;
  }

  Future<List<OrderItem>> get_purchasedItems(int customer_id) async { //from all items, isComplete = true items is chosen
    List list = await _parseItems(customer_id); //submit customer id as global variable
    List<OrderItem> purchasedItems = <OrderItem>[];

    for(var i=0; i<list.length; i++)
    {
      if(list[i].order.isComplete == true)
      {
        purchasedItems.add(list[i]);
        print(list[i].quantity.toString());
      }
    }
    return purchasedItems;
  }

  @override
  Widget projectWidgetOldies() {
    return FutureBuilder(
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.none &&
            projectSnap.hasData == null) {
          //print('project snapshot data is: ${projectSnap.data}');
          return Container();
        }
        return ListView.builder(


          itemCount: projectSnap?.data?.length ?? 0,
          itemBuilder: (context, index) {
            OrderItem project = projectSnap.data[index];
            return Olditems(
              pro1: project,
            );
          },
        );
      },
      future: get_purchasedItems(global_customer_id),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.deepOrange,
        title: Text('My Orders'),
      ),
      body: projectWidgetOldies(),


    );
  }
}

class Olditems extends StatelessWidget {
  final OrderItem pro1;

  Olditems({@required this.pro1,
  });
  Widget build(BuildContext context){
     return Card(
        elevation: 4.0,
        child: Material(
          child: InkWell( onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (context) => new ProductDetailsOld(
            //passing values of the product to the productdetail page
            pd:pro1,
          ))),
            child:ListTile(
            leading: Image.network('http://10.0.2.2:8000/images/' + pro1.product.image,fit: BoxFit.cover,),
            title: Text(pro1.product.albumName),
            trailing: Wrap(
                spacing: 12,
                children: <Widget>[
                  Text('quantity ' + pro1.quantity.toString()),
                ]
            ),
          ),)
        ),
      );

  }
}
class ProductDetailsOld extends StatefulWidget{
  final OrderItem pd;


  ProductDetailsOld({this.pd});
  @override
  _ProductDetailsOldState createState() => _ProductDetailsOldState();
}
class _ProductDetailsOldState extends State<ProductDetailsOld>{
  var feedback2;
  var rating2;





  void _showFeedback(context) {
    showDialog(
      context: context,
      builder: (context) {
        return QuickFeedback(
          title: 'Rate the Vinyl!',
          showTextBox: true,
          textBoxHint:
          'What are your thoughts ?',
          submitText: 'SUBMIT',
          onSubmitCallback: (feedback) {
            rating2 = feedback['rating'];
            feedback2 = feedback['feedback'];
            if(rating2 != null) {
              widget.pd.rating = rating2;
              var a = GiveRatingApi(widget.pd, "AddRating");
            }
            if(feedback2 != null)
              {
                var b = AddCommentApi(widget.pd, feedback2);
              }

            print('$feedback');
            Navigator.of(context).pop(); //JASON HALİNDELER HAZIR BİR ŞEKİLDE BUNLARI ALIP BİŞEKİLDE EŞİTLERSİN
          },
          askLaterText: 'ASK LATER',
          onAskLaterCallback: () {
            print('Do something on ask later click');
          },
        );
      },
    );
  }
  @override
  Widget _getFAB() {
    return SpeedDial(
      overlayOpacity: 0.4,
      animatedIcon: AnimatedIcons.menu_close,
      animatedIconTheme: IconThemeData(size: 22),
      backgroundColor: Colors.orange,
      visible: true,
      curve: Curves.bounceIn,
      children: [
        // FAB 1
        SpeedDialChild(
            child: Icon(Icons.add_comment_outlined),
            backgroundColor: Color(0xFF801E48),
            onTap: () async {
              _showFeedback(context);
            },
            label: 'Give a Feedback',
            labelStyle: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.white,
                fontSize: 16.0),
            labelBackgroundColor: Color(0xFF801E48)),
        SpeedDialChild(
            child: Icon(Icons.assignment_turned_in),
            backgroundColor: Color(0xFF801E48),
            onTap: () async {
              setState(() {
                AskRefundApi(widget.pd);
              });
            },
            label: 'Ask For a Refund',
            labelStyle: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.white,
                fontSize: 16.0),
            labelBackgroundColor: Color(0xFF801E48)),
      ],
    );
  }
  @override
  Widget build(BuildContext context){
    String where_pro(){
      if(widget.pd.order.status==1)
        return('We are preparing your precious.');
      else if(widget.pd.order.status==2)
        return('Your precious is on the way.');
      else if(widget.pd.order.status==3)
        return('You have your precious.');
      else
        return('OOoops');
    }
    return Scaffold(
        appBar: new AppBar(
          elevation: 0.1,
          backgroundColor: Colors.deepOrange,
          title: Text('PWAK', style: GoogleFonts.chivo(),),
          actions: <Widget> [
            new IconButton(icon: Icon(Icons.search, color: Colors.white,), onPressed:null,),
          ],
        ),
        body: new ListView(
            children: <Widget>[
              new Container(
                  height:300.0,
                  child: GridTile(
                    child: Container(
                        color: Colors.white,
                        child: Image.network('http://10.0.2.2:8000/images/' + widget.pd.product.image,fit: BoxFit.cover,)
                    ),
                    footer: new Container(
                      color: Colors.white70,
                      child: ListTile(
                        leading: new Text(widget.pd.product.albumName, style: TextStyle(fontWeight: FontWeight.bold),),//leading is left
                        title: new Row(
                          children: <Widget>[
                            Expanded(child: new Text(widget.pd.product.price))
                          ],
                        ),
                      ),
                    ),
                  )// in this part we will have a image when we get from the api
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('You bought this item at ' + widget.pd.dateAdded.substring(0,10),style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('In ' + widget.pd.quantity.toString() + ' quantities' ,style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(where_pro(),style: TextStyle(letterSpacing: 1.2, backgroundColor: Colors.orange ,fontWeight: FontWeight.bold))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          projectWidgetRefund(widget.pd),
                        ],
                      ),
                    ),
                  ],

                ),
              ),
            ]
        ),
        floatingActionButton: _getFAB(),

    );
  }
}