import 'dart:ffi';
import 'dart:ui';
import 'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import 'package:cs308_plaqstore/forms/ProductListPageForm.dart';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:cs308_plaqstore/forms/OldOrders.dart';

import 'package:cs308_plaqstore/forms/cart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'horizontal_list.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'loginForm.dart';

class UserInfo extends StatefulWidget {
  String username;
  UserInfo(this.username);
  @override
  UserInfoState createState() => UserInfoState(this.username);
}

class UserInfoState extends State<UserInfo> {
  UserInfoState(this.username);

  String username;

  Uri getUser(String username) =>
      Uri.parse(
          'http://10.0.2.2:8000/api/example/?username=' + username);

  Future<dynamic> searchUser(String username) async {
    final uri = getUser(username);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }

  Future<List<Customer_Profile>> _parseUser(String username) async {
    List<Customer_Profile> productsList = <Customer_Profile>[];
    print("Profilform parseUser");

    var dataFromResponse = await searchUser(username);

    dataFromResponse.forEach(
          (User) {
        //parse new product's details
        Customer_Profile thisuser = new Customer_Profile(
          Name: User["first_name"],
          Surname: User["last_name"],
          emailAddress: User["email"],
          id: User["id"],
        );

        print(thisuser);
        global_customer_id = thisuser.id;
        productsList.add(thisuser);
      },
    );
    return productsList;
  }

  Widget projectWidgetUserPage(String username) {
    return FutureBuilder(
      future: _parseUser(username),
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.waiting &&
            projectSnap.hasData == null) {
          return Container();
        }
        else if(projectSnap.connectionState == ConnectionState.done && projectSnap.hasData != null){
          Customer_Profile project = projectSnap.data[0];

          return  UserInfoColumn(
              context,project
          );
        }
        return Container();

      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return projectWidgetUserPage(username);
  }
}

   UserInfoColumn(context,project) {
     final authBloc = BlocProvider.of<AuthenticationBloc>(context);
     final Customer_Profile pro1=project;
    return  Drawer(
      child: ListView(
        children: <Widget>[
          //header
          UserAccountsDrawerHeader(accountName: Text(pro1.Name + pro1.Surname),
            accountEmail: Text(pro1.emailAddress),
            currentAccountPicture: GestureDetector(
              child: new CircleAvatar(backgroundColor: Colors.grey,
                child: Icon(Icons.person, color: Colors.white),
              ),
            ),
            decoration:
              BoxDecoration(color:Colors.deepOrange),
          ),
          InkWell(
            onTap: () {},
            child: ListTile(
              title: Text('My Account'),
              leading: Icon(Icons.person),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => OldOrders(),
                ),
              );
            },
            child: ListTile(
              title: Text('My Orders'),
              leading: Icon(Icons.shopping_basket),
            ),
          ),
          Divider(),
          InkWell(
            onTap: () {},
            child: ListTile(
              title: Text('Settings'),
              leading: Icon(Icons.settings),
            ),
          ),
          InkWell(
            onTap: () {},
            child: ListTile(
              title: Text('About'),
              leading: Icon(Icons.help, color: Colors.blue),
            ),
          ),
          InkWell(
            onTap: () {
              authBloc.add(LoggedOut());
            },
            child: ListTile(
              title: Text('Logout'),
              leading: Icon(Icons.logout, color: Colors.blue),
            ),
          ),
        ],

      ),
    );
  }
