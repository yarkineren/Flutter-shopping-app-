
import 'dart:convert';

import 'package:cs308_plaqstore/flutter_api/user_repository.dart';
import 'package:cs308_plaqstore/forms/profileForm.dart';
import 'package:cs308_plaqstore/forms/ProductListPageForm.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../globals.dart';
import '../model.dart';
import 'Products.dart';

class sort extends StatefulWidget {
  const sort();

  @override
  _sortState createState() => _sortState();
}

class _sortState extends State<sort> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.deepOrange,
        title: Text('PWAK', style: GoogleFonts.chivo(),),),
      body: projectWidgetsort(),
    );
  }
  Widget projectWidgetsort() {
    return FutureBuilder(
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.none &&
            projectSnap.hasData == null) {
          //print('project snapshot data is: ${projectSnap.data}');
          return Container();
        }
        return GridView.builder(

          itemCount: projectSnap?.data?.length ?? 0,
          gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          itemBuilder: (context, index) {
            Product project = projectSnap.data[index];
            return ProductListItem(
              pro1: project,
            );
          },
        );
      },
      future: _parseProductsFromResponse(),
    );
  }
}
Future<dynamic> _getProductsByCategory() async {
  print("ProductListPageForm getProductsByCategory");
  var response = await http.get(Uri.parse(
      RemoteConfig.config["BASE_URL"] +
          RemoteConfig.config["BASE_PRODUCTS_URL"]
  ),
    headers: {
      "Authorization": RemoteConfig.config[mytoken],
    },
  ).catchError(
        (error) {
      return false;
    },
  );
  return json.decode(response.body);
}
Future<List<Product>> _parseProductsFromResponse() async {
  List<Product> productsList = <Product>[];
  print("ProductListPageForm parseProductsFromResponse");
  var setCustomerID = await UserInfo(globalusername);

  var dataFromResponse = await _getProductsByCategory();

  dataFromResponse.forEach(
        (newProduct) {
      //parse new product's details
      Product product = new Product(
        modelNo: newProduct["model_no"],
        albumName: newProduct["album_name"],
        artistName: newProduct["artist_name"],
        description: newProduct["description"],
        price: newProduct["price"],
        warranty: newProduct["warranty"],
        genre: newProduct["genre"],
        distributor: newProduct["distributor"],
        image: newProduct["image"],
        stock: newProduct["stock"] != null
            ? newProduct["stock"]
            : 0,
        average_rating: newProduct["average_rating"],
        onDiscount:  newProduct['onDiscount'],
        //images: imagesOfProductList,
      );

      print(product);

      productsList.add(product);
    },
  );
  print("ProductListPageForm parseProductsFromResponse returns");
  productsList.sort((a, b) => a.price.compareTo(b.price));
  return productsList;
}
