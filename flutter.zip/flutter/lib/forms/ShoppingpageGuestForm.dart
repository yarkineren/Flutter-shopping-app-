import 'dart:ffi';
import 'dart:ui';

import 'package:cs308_plaqstore/forms/ProductListPageForm.dart';
import 'package:cs308_plaqstore/forms/loginForm.dart';
import 'package:cs308_plaqstore/forms/sort.dart';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/forms/profileForm.dart';
import 'package:cs308_plaqstore/main.dart';

import 'package:cs308_plaqstore/model.dart';

import 'package:cs308_plaqstore/forms/cart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Product_details.dart';
import 'horizontal_list.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'package:cs308_plaqstore/flutter_api/bloc/authentication_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:material_floating_search_bar/material_floating_search_bar.dart';



class ShoppingpageGuestForm  extends StatefulWidget{
  @override
  State<StatefulWidget> createState()
  {
    return ShopPageGuest();
  }
}
class ShopPageGuest extends State<ShoppingpageGuestForm> {
  void refresh(){
    setState(() {

    });
  }


  Widget build(BuildContext context) {
    final authBloc = BlocProvider.of<AuthenticationBloc>(context);

    Widget image_carousel = new Container(
      height: 200.0,
      child: new Carousel(
        boxFit: BoxFit.cover,
        images: [
          Image(image: new AssetImage("assets/vinyl-opt2.gif")),
          AssetImage('assets/dua.jpg'),
          AssetImage('assets/nevermind.jpg'),
        ],
        autoplay: false,
        dotSize: 0.0,
        indicatorBgPadding: 3.0,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(milliseconds: 1000),
      ),

    );

    return Scaffold(

        appBar: new AppBar(
          elevation: 0.1,
          backgroundColor: Colors.deepOrange,
          title: Text('PWAK', style: GoogleFonts.chivo(),),
          actions: <Widget>[
            new IconButton(
              icon: Icon(Icons.search, color: Colors.white,), onPressed: () {
              Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => buildFloatingSearchBarState(),)
              );
            },),
            new IconButton(
              icon: Icon(Icons.shopping_cart, color: Colors.white,),
              onPressed: () {
                if (Mycart.isNotEmpty)
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => cart(Mycart),)
                  );
              },),
            IconButton(onPressed: refresh, icon: Icon(Icons.wifi_protected_setup)),
          ],
        ),
        drawer: new Drawer(
          child: new ListView(
            children: <Widget>[
              //header
              new UserAccountsDrawerHeader(accountName: Text('Guest'),
                accountEmail: Text(
                    'Please log in to access full features of the app'),
                decoration:
                BoxDecoration(color: Colors.deepOrange),
              ),
              InkWell(
                onTap: () {
                  int count = 0;
                  Navigator.popUntil(context, (route) {
                    return count++ == 2;
                  });
                  //burada da anaysayfaya gitmem lazım
                },
                child: ListTile(

                  title: Text('Login'),
                  leading: Icon(Icons.login, color: Colors.deepOrange),
                ),
              ),
              //body
              Divider(),
              InkWell(
                onTap: () {},
                child: ListTile(
                  title: Text('Settings'),
                  leading: Icon(Icons.settings),
                ),
              ),
              InkWell(
                onTap: () {},
                child: ListTile(
                  title: Text('About'),
                  leading: Icon(Icons.help, color: Colors.blue),
                ),
              ),
            ],

          ),
        ),


        body: new ListView(
          children: <Widget>[
            image_carousel,
            //padding widget
            new Padding(padding: const EdgeInsets.all(18.0),
              child: new Text('Categories'),
            ),
            //horizontal list
            horizontal_list(),

            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: RaisedButton(
                      color: Colors.deepOrange,
                      elevation: 2,
                      focusElevation: 4,
                      hoverElevation: 4,
                      highlightElevation: 8,
                      disabledElevation: 0,
                      onPressed: () {Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => sort(),)
                      ); },
                      child: Text('Sort by price'),
                    ),
                  ),
                ],
              ),
            ),

            Container(
              height: 320,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ProductsListPage_guest(),
              ),
            ),

            /*Container(
            height: 320.0,
            child:
          )*/


          ],
        )

    );
  }
}
class buildFloatingSearchBarState  extends StatefulWidget{
  @override
  State<StatefulWidget> createState()
  {
    return buildFloatingSearchBarState2();
  }
}

class buildFloatingSearchBarState2 extends State<buildFloatingSearchBarState> {
  List<Product> searchResults = [];

  static Future<dynamic> searchDjangoApi(String value) async {
    String url = 'http://10.0.2.2:8000/api/product-user-search/?search=$value';
    Uri search_url = Uri.parse(url);
    final response = await http.get(search_url);
    var check = response.body;

    return json.decode(response.body);
  }

  searchDjango(String value) async {
    var responseBody = await searchDjangoApi(value);

    setState(() {
      responseBody.forEach((value) {
        Product searchproduct = new Product.fromJson(value);
        searchResults.add(searchproduct);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isPortrait = MediaQuery.of(context).orientation == Orientation.portrait;

    return MaterialApp(
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: <Widget> [
            FloatingSearchBar(
              hint: 'Search...',
              scrollPadding: const EdgeInsets.only(top: 16, bottom: 56),
              transitionDuration: const Duration(milliseconds: 800),
              transitionCurve: Curves.easeInOut,
              physics: const BouncingScrollPhysics(),
              axisAlignment: isPortrait ? 0.0 : -1.0,
              openAxisAlignment: 0.0,
              width: isPortrait ? 600 : 500,
              debounceDelay: const Duration(milliseconds: 500),
              onQueryChanged: (query) {
                searchResults.clear();
                searchDjango(query);
                //look from here
                // Call your model, bloc, controller here.
              },
              // Specify a custom transition to be used for
              // animating between opened and closed stated.
              transition: CircularFloatingSearchBarTransition(),
              actions: [
                FloatingSearchBarAction(
                  showIfOpened: false,
                  child: CircularButton(
                    icon: const Icon(Icons.wb_sunny_sharp),
                    onPressed: () {
                    },
                  ),
                ),
                FloatingSearchBarAction.searchToClear(
                  showIfClosed: false,
                ),
              ],
              builder: (context, transition) {
                return ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Material(
                    color: Colors.deepOrange,
                    elevation: 4.0,
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          ListView.builder(
                            shrinkWrap: true,
                            itemCount: searchResults.length,
                            itemBuilder: (context,index){
                              return buildResultCard(context,searchResults[index]);
                            },
                          ),

                        ]

                    ),),);
              },
            ),
          ],
        ),
      ),
    );
  }



}




Widget buildResultCard(context,item){
  return Padding(
    padding: const EdgeInsets.symmetric(
        horizontal: 8.0, vertical: 2.0),
    child: Card(
      elevation: 4.0,
      child: InkWell(
        onTap: () => Navigator.of(context).push(new MaterialPageRoute(builder: (context) => new ProductDetails(
          //passing values of the product to the productdetail page
          pd:item,
        ))),

        child: ListTile(
            leading: Image.network(
              'http://10.0.2.2:8000/images/' + item.image,
              fit: BoxFit.cover,),
            title: Text(item.albumName),
            trailing: Text(item.artistName)
        ),
      ),
    ),

  );
}