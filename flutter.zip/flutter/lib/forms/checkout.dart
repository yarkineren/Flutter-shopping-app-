import 'dart:math';

import 'package:cs308_plaqstore/forms/thankyou.dart';
import 'package:cs308_plaqstore/model.dart';
import 'package:flutter/cupertino.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cs308_plaqstore/globals.dart' as globals;
import 'dart:async';
import 'dart:convert';

//CCV'Yİ APİDEN ÇIKARTIM (MODELDE YOK)
//DAHA FAZLA VALIDATION GEREKIYOR. KREDI KARTI NUMARASI SAYILARDAN OLUSMALI VS.
//STATIK ONAY SAYFASI CIKMALI (LINE 379)

PurchaseSucceeded(
    List<OrderItem> cartlist, CreditCard k, Shipping c, String message) async {
  String base = "http://10.0.2.2:8000/api/shipping-address/";
  Shipping _shipping = new Shipping();
  _shipping = c;

  Order _order = new Order();
  _order = cartlist[0].order;
  Customer _customer = new Customer();
  _customer = cartlist[0].order.customer;
  _order.customer = _customer;
  _shipping.order = _order;
  _shipping.customer = _customer;
  //_orderItem.order.customer.username = globals.globalusername;
  _shipping.address = c.address;
  _shipping.city = c.city;
  _shipping.state = c.state;
  _shipping.country = c.country;
  _shipping.zipcode = c.zipcode;

  var shipping_value = _shipping.toJson();
  var event = {};
  var message_type = message;
  event["message_type"] = message_type;
  event["event"] = shipping_value;
  var shipping_data = json.encode(event);

  print(shipping_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: shipping_data);
  print(response);

  return response.statusCode;
}

Future<int> ApplyShippingPostOperation(
    List<OrderItem> cartlist, CreditCard k, Shipping c, String message) async {
  String base = "http://10.0.2.2:8000/api/shipping-address/";
  Shipping _shipping = new Shipping();
  _shipping = c;

  Order _order = new Order();
  _order = cartlist[0].order;
  Customer _customer = new Customer();
  _customer = cartlist[0].order.customer;
  _order.customer = _customer;
  _shipping.order = _order;
  _shipping.customer = _customer;
  //_orderItem.order.customer.username = globals.globalusername;
  _shipping.address = c.address;
  _shipping.city = c.city;
  _shipping.state = c.state;
  _shipping.country = c.country;
  _shipping.zipcode = c.zipcode;

  var shipping_value = _shipping.toJson();
  var event = {};
  var message_type = message;
  event["message_type"] = message_type;
  event["event"] = shipping_value;
  var shipping_data = json.encode(event);

  print(shipping_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: shipping_data);
  print(response);

  if (response.statusCode == 201) {
    var parallel = await ApplyBillingPostOperation(k, c);
    if (parallel == 201 && response.statusCode == 201) {

      return 201;
      //Success
    } else {
      return 501;
      //billing info has problems
    }
  } else {
    return 500;
    //both have problems
  } //response.statusCode;
}

Future<int> ApplyBillingPostOperation(CreditCard k, Shipping c) async {
  String base = "http://10.0.2.2:8000/api/credit-card/";
  CreditCard _card = new CreditCard();
  //_card = k;
  Customer _customer = new Customer();
  _customer.username = globals.globalusername;
  _card.customer = _customer;
  //_orderItem.order.customer.username = globals.globalusername;
  _card.expdate = k.expdate;
  //_card.cardcvv = k.cardcvv;
  _card.cardname = k.cardname;
  _card.cardNo = k.cardNo;

  var billing_value = _card.toJson();
  var event = {};
  event["event"] = billing_value;
  var billing_data = json.encode(event);

  print(billing_data);

  final response = await http.post(Uri.parse(base),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: billing_data);
  print(response);

  return response.statusCode;
}

// MANUEL VALIDATION CLASSES FOR THE UNIT TESTS

// Credit Card Information Validators

class CardNameFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'card name can\'t be empty' : null;
  }
}

class CardNameVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card name is valid ?' : null;
  }
}

class CardNameIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card name is invalid ?' : null;
  }
}

class CardNoFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'card number can\'t be empty' : null;
  }
}

class CardNoVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card number is valid ?' : null;
  }
}

class CardNoIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card number is invalid ?' : null;
  }
}

class CardCvvFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'card cvv can\'t be empty' : null;
  }
}

class CardCvvVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card cvv is valid ?' : null;
  }
}

class CardCvvIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'card cvv is invalid ?' : null;
  }
}

class CardDateFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'expiration date can\'t be empty' : null;
  }
}

class CardDateVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'expiration date is valid ?' : null;
  }
}

class CardDateIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'expiration date is invalid ?' : null;
  }
}

// Address Information Validators

class AddressFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'adress can\'t be empty' : null;
  }
}

class AddressVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'Address is valid ?' : null;
  }
}

class AddressIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'Address is invalid ?' : null;
  }
}

class CityFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'City can\'t be empty' : null;
  }
}

class CityVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'City is valid ?' : null;
  }
}

class CityIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'City is invalid ?' : null;
  }
}

class StateFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'State can\'t be empty' : null;
  }
}

class StateVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'State is valid ?' : null;
  }
}

class StateIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'State is invalid ?' : null;
  }
}

class CountryFieldValidator {
  static String validate(String value) {
    return value.isEmpty ? 'Country can\'t be empty' : null;
  }
}

class CountryVFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'Country is valid ?' : null;
  }
}

class CountryIFieldValidator {
  static String validate(String value) {
    return value.isNotEmpty ? 'Country is invalid ?' : null;
  }
}

class CheckoutPage extends StatefulWidget {
  final List<OrderItem> Cartlist;

  CheckoutPage(this.Cartlist);

  @override
  _CheckoutState createState() => _CheckoutState(this.Cartlist);
}

class _CheckoutState extends State<CheckoutPage> {
  final List<OrderItem> Cartlist;
  _CheckoutState(this.Cartlist);
  final _formKey = GlobalKey<FormState>(); // 1. Formun anahtarı
  final _abcKey = GlobalKey<FormState>(); // 2. Formun anahtarı

  Shipping c = Shipping();
  CreditCard k = CreditCard();

  String zip;
  String address;
  String country;
  String city;
  String state;

  //THESE ARE NOW ATTRIBUTES OF CREDITCARD MODEL
  String cardNo;
  String cardname;
  String cardcvv;
  String expdate;

  showAlertDialogCheckout(BuildContext context) {
    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Sorry!"),
      content:
          Text("We can't process your purchase now. Please try again later."),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: Text("Check Out"),
          backgroundColor: Colors.deepOrange,
        ),
        body: SingleChildScrollView(
          reverse: true,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 300),
            child: Column(
              children: <Widget>[
                getShippingWidget(),
                getBillingWidget(),
                getContinueWidget(c,
                    k), //SHOULD TAKE 2 PARAMETERS NOW. SHIPPING AND CREDIT CARD
              ],
            ),
          ),
        ));
  }

  Form getShippingWidget() {
    return Form(
      key: _formKey,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text("Shipping Information:",
                style: Theme.of(context).textTheme.headline6),
            Row(children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Address must not be empty.';
                      }
                      return null;
                    },
                    onChanged: (String value) {
                      c.address = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Address",
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'City must not be empty.';
                      }
                      return null;
                    },
                    onChanged: (String value) {
                      c.city = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "City",
                    ),
                  ),
                ),
              )
            ]),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 300,
                child: TextFormField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'State must not be empty.';
                    }
                    return null;
                  },
                  onChanged: (String value) {
                    c.state = value;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "State",
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 300,
                child: TextFormField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Country must not be empty.';
                    }
                    return null;
                  },
                  onChanged: (String value) {
                    c.country = value;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Country",
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 100,
                child: TextFormField(
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Zip must not be empty.';
                    } else if (int.tryParse(value) < 100) {
                      return 'Please enter a valid zipcode';
                    } else {
                      return null;
                    }
                  },
                  onChanged: (String value) {
                    c.zipcode = value;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Zip code",
                  ),
                ),
              ),
            ),
          ]),
    );
  }

  Form getBillingWidget() {
    return Form(
      key: _abcKey,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text("Billing Information:",
                style: Theme.of(context).textTheme.headline6),
            Row(children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      RegExp reg = new RegExp(r"/^\d+$/");
                      if (value.isEmpty) {
                        return 'Card NO must not be empty.';
                      } else if (value.length != 16) {
                        return 'Your card number doesn\'t match.';
                      //} else if (!reg.hasMatch(value)) {
                       // return 'Please enter a valid Card number.';
                      } else {
                        return null;
                      }
                    },
                    onChanged: (String value) {
                      k.cardNo = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Card No",
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 150,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Name/Surname must not be empty.';
                      } else if (value.length < 3 && value.isNotEmpty) {
                        return 'Your name is not that short';
                      } else {
                        return null;
                      }
                    },
                    onChanged: (String value) {
                      k.cardname = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Name, Surname",
                    ),
                  ),
                ),
              )
            ]),
            Row(children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 100,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'CVV must not be empty.';
                      } else if (int.tryParse(value) > 999) {
                        return 'CVV is not that long';
                      } else if (int.tryParse(value) < 100) {
                        return 'CVV is not that short';
                      } else {
                        return null;
                      }
                    },
                    onChanged: (String value) {
                      k.cardcvv = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "CVV",
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 100,
                  child: TextFormField(
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Expiration date must not be empty.';
                        } else if (value.length != 4) {
                        return 'Please enter a valid date.';
                      } else {
                        return null;
                      }
                    },
                    onChanged: (String value) {
                      k.expdate = value;
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "MM/YY",
                    ),
                  ),
                ),
              )
            ]),
          ]),
    );
  }

  Widget getContinueWidget(Shipping c, CreditCard k) {
    return Container(
      width: 300,
      child: MaterialButton(
          onPressed: () async {
            if (!_formKey.currentState.validate()) {}
            if (!_abcKey.currentState.validate()) {}
            int response_billing = await ApplyShippingPostOperation(Cartlist, k, c, "PostShipping");
            print(response_billing);
            //Navigator.of(context).push(MaterialPageRoute(
            // builder: (context) => ThankyouPage(),
            //  ));
            if (response_billing == 201) {
               PurchaseSucceeded(Cartlist, k, c, "PurchaseSuccess");
                //THANK YOU FOR YOUR ORDER WIDGET HERE.
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => ThankyouPage(),
                ));
                print("Purchase Successful");

              //orderitem: completeorder is true (update api)
            } else {
              showAlertDialogCheckout(context);
            }
          },
          child: Text(
            'Continue',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          color: Colors.deepOrange),
    );
  }
}
