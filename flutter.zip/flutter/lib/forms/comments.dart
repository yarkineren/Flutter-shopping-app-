import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:core';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:cs308_plaqstore/model.dart';

  Future<dynamic> getdata(String albumname) async {
    final uri =  Uri.parse('http://10.0.2.2:8000/api/comments/?product=' + albumname);
    final response = await http.get(uri);
    if (response.statusCode == 200)
      return json.decode(response.body);
  }
  Future<List<comment>> _parseItems(String albumname) async {
    List<comment> AllItemList = <comment>[
    ]; //all item list will be user's orders' items, without further filtration
    var dataFromResponse = await getdata(albumname);

    dataFromResponse.forEach((Item) {
      comment mycomment = new comment.fromJson(Item);
      if(mycomment.approval == 2)
        {
          AllItemList.add(mycomment);
          print(mycomment.body);
        }

    });

    return AllItemList;
  }
  Widget CommentBuilder(String albumname) {
    return FutureBuilder(
      builder: (context, projectSnap) {
        if (projectSnap.connectionState == ConnectionState.none &&
            projectSnap.hasData == null) {
          //print('project snapshot data is: ${projectSnap.data}');
          return Container();
        }
        return ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: projectSnap?.data?.length ?? 0,
          itemBuilder: (context, index) {
            comment project = projectSnap.data[index];
            return 
               SingleComment(
                myComment: project,
              );
            
          },
        );
      },
      future: _parseItems(albumname),
    );
  }
class SingleComment extends StatelessWidget {
  final comment myComment;

  SingleComment({@required this.myComment,
  });
  Widget build(BuildContext){
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
        child: Card(
          elevation: 1.0,
          child: ListTile(
            leading: Text(myComment.user.username + ':'),
            title: Text(myComment.body),
            trailing: Wrap(
                spacing: 12,
                children: <Widget>[
                  Text(myComment.date.substring(0,7)),
                ]
            ),
          ),
        ),

      );


  }

}
