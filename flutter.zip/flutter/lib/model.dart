import 'dart:convert';
import 'package:cs308_plaqstore/globals.dart';
import 'package:cs308_plaqstore/product_model.dart';
import 'package:flutter/material.dart';
import'package:http/http.dart' as http;

class Customer2 {
  //TAX-ID?
  String firstName;
  String lastName;
  String username;
  String email;
  String homeAddress;
  String password;

  //!!!!!! CODE IS INCORRECT, EDIT THIS WHEN ITS FIXED
  Future<void> signUpCustomer() async {
    final url  = Uri.parse('remotemysql.com'); //WRITE SERVER ADDRESS HERE
    var body =
    {
      'call' : 'signup',
      'name' : firstName + lastName,
      'user_password' : password,
      'USER_ID' : username, //ADD THIS IF MISSING
      'home_address': homeAddress,
      'email': email
    };

    final response = await http.post(
      Uri.http(url.authority, url.path),
      headers: <String, String>
        {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      },
      body: body,
      encoding: Encoding.getByName("utf-8"),
    );

    if(response.statusCode >= 200 && response.statusCode < 300)
      {
        Map<String, dynamic> jsonMap = json.decode(response.body);

        for(var entry in jsonMap.entries)
        {
          print("${entry.key} ==> ${entry.value}");
        }
      }
    else if(response.statusCode >= 400 && response.statusCode < 500)
      {
        Map<String,dynamic> jsonMap = json.decode(response.body);
        for(var entry in jsonMap.entries)
        {
          print("${entry.key} ==> ${entry.value}");
        }
        //showAlertDialog('WARNING', jsonMap['error_msg']);
      }
    else
      {
        print(response.body.toString());
        print(response.statusCode);
      }
  }
  Customer2({this.firstName, this.lastName, this.username, this.email, this.homeAddress, this.password});
}

//API
class User {
  int id;
  String username;
  String token;

  User(
      {this.id,
        this.username,
        this.token});

  factory User.fromDatabaseJson(Map<String, dynamic> data) => User(
    id: data['id'],
    username: data['username'],
    token: data['token'],
  );

  Map<String, dynamic> toDatabaseJson() => {
    "id": this.id,
    "username": this.username,
    "token": this.token
  };

  setUsernameAsGlobal() async {
    await User();
   globalusername = username;
   print(globalusername + "set as global username");
  }
}


class Customer_Profile
{
  String Name;
  String Surname;
  String emailAddress;
  int id;


  Customer_Profile({
    this.Name,
    this.Surname,
    this.emailAddress,
    this.id,
});

  factory Customer_Profile.fromDatabaseJson(Map<String, dynamic> data) => Customer_Profile(
    Name: data['Name'],
    Surname: data['Surname'],
    emailAddress: data['emailAddress'],
    id: data['id'],
  );

  Map<String, dynamic> toDatabaseJson() => {
    "Name": this.Name,
    "Surname": this.Surname,
    "emailAddress": this.emailAddress,
    "id": this.id,
  };



  //profile picture
  //orders
  //My reviews
  //Settings
}

class Customer_Review
{
  String text;
  String date;
  int likes;
  int comments;

  Customer_Review({this.text, this.date, this.likes, this.comments });

}

//ORDERS, CART ITEMS, PURCHASED ITEMS -MADE 0N 7.5.21

//ORDERS, CART ITEMS, PURCHASED ITEMS -MADE 0N 7.5.21
class OrderItem {
  //OrderItem event;
  //String message_type;
  int id;
  Product product;
  Order order;
  int quantity;
  String dateAdded;
  int rating;
  OrderItem ({this.id, this.product, this.order, this.quantity, this.dateAdded, this.rating});

  OrderItem.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    product = json['product'] != null ? new Product.fromJson(json['product']) : null;
    order = json['order'] != null ? new Order.fromJson(json['order']) : null;
    quantity = json['quantity'];
    dateAdded = json['date_added'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.product != null) {
      data['product'] = this.product.toJson();
    }
    if (this.order != null) {
      data['order'] = this.order.toJson();
    }
    //data['event'] = this.event;
   // data['message_type'] = this.message_type;
    data['id'] = this.id;
    data['quantity'] = this.quantity;
    data['date_added'] = this.dateAdded;
    data['rating'] = this.rating;
    return data;
  }
}

class Product {
  String modelNo;
  String albumName;
  String artistName;
  String description;
  String genre;
  String warranty;
  String distributor;
  String price;
  String stock;
  String image;
  double average_rating;
  bool onDiscount;


  Product(
      {this.modelNo,
        this.albumName,
        this.artistName,
        this.description,
        this.genre,
        this.warranty,
        this.distributor,
        this.price,
        this.stock,
        this.image,
      this.average_rating,this.onDiscount});

  Product.fromJson(Map<String, dynamic> json) {
    modelNo = json['model_no'];
    albumName = json['album_name'];
    artistName = json['artist_name'];
    description = json['description'];
    genre = json['genre'];
    warranty = json['warranty'];
    distributor = json['distributor'];
    price = json['price'];
    stock = json['stock'];
    image = json['image'];
    average_rating = json['average_rating'];
    onDiscount = json['onDiscount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['model_no'] = this.modelNo;
    data['album_name'] = this.albumName;
    data['artist_name'] = this.artistName;
    data['description'] = this.description;
    data['genre'] = this.genre;
    data['warranty'] = this.warranty;
    data['distributor'] = this.distributor;
    data['price'] = this.price;
    data['stock'] = this.stock;
    data['image'] = this.image;
    data['onDiscount'] = this.onDiscount;
    return data;
  }
}

class Order {
  int id;
  Customer customer;
  String orderDate;
  bool isComplete;
  String transactionId;
  int status;

  Order({this.id, this.customer, this.orderDate, this.isComplete, this.transactionId,this.status});

  Order.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    customer = json['customer'] != null
        ? new Customer.fromJson(json['customer'])
        : null;
    orderDate = json['order_date'];
    isComplete = json['isComplete'];
    transactionId = json['transaction_id'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.customer != null) {
      data['customer'] = this.customer.toJson();
    }
    data['order_date'] = this.orderDate;
    data['isComplete'] = this.isComplete;
    data['transaction_id'] = this.transactionId;
    data['status'] = this.status;
    return data;
  }
}

class Shipping {
  String zipcode;
  String address;
  String country;
  String city;
  String state;
  Order order;
  Customer customer;

  Shipping(
      {this.zipcode,
        this.address,
        this.country,
        this.city,
        this.state,
      this.order,
      this.customer});

  Shipping.fromJson(Map<String, dynamic> json) {
    order = json['order'] != null ? new Order.fromJson(json['order']) : null;
    customer = json['customer'] != null ? new Customer.fromJson(json['customer']) : null;
    zipcode = json['zipcode'];
    address = json['address'];
    country = json['country'];
    city = json['city'];
    state = json['state'];
  }

    Map<String, dynamic> toJson() {
      final Map<String, dynamic> data = new Map<String, dynamic>();
      if (this.customer != null) {
        data['customer'] = this.customer.toJson();
      }
      if (this.order != null) {
        data['order'] = this.order.toJson();
      }
      data['zipcode'] = this.zipcode;
      data['address'] = this.address;
      data['country'] = this.country;
      data['city'] = this.city;
      data['state'] = this.state;
      return data;
    }

}


class CreditCard
{
  Customer customer;
  String cardNo;
  String cardname;
  String cardcvv;
  String expdate;

  CreditCard({
    this.cardNo,
    this.cardname,
    this.cardcvv,
    this.expdate,
    this.customer,
});

CreditCard.fromJson(Map<String, dynamic> json) {
  customer = json['customerID'] != null ? new Customer.fromJson(json['customerID']) : null;
  cardNo = json['cardNumber'];
  cardname = json['cardName'];
 // cardcvv = json['CardCVV'];
  expdate = json['exprDate'];
}

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.customer != null) {
      data['customerID'] = this.customer.toJson();
    }
    data['cardNumber'] = this.cardNo;
    data['cardName'] = this.cardname;
  //  data['CardCVV'] = this.cardcvv;
    data['exprDate'] = this.expdate;
    return data;
  }

}
class Customer {
  int id;
  String username;
  String firstName;
  String lastName;
  String email;
  String password;

  Customer(
      {this.id,
        this.username,
        this.firstName,
        this.lastName,
        this.email,
        this.password});

  Customer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
    password = json['password'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['password'] = this.password;
    return data;
  }

}
class comment{
  Product product;
  Customer user;
  String date;
  String body;
  int approval;
  comment({this.product,this.user,this.date,this.body,this.approval});
  comment.fromJson(Map<String, dynamic> json) {
    product = json['product'] != null ? new Product.fromJson(json['product']) : null;
    user = json['user'] != null ? new Customer.fromJson(json['user']) : null;
    date = json['date_added'];
    body = json['body'];
    approval = json['approval'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['product'] = this.product;
    data['user'] = this.user;
    data['date_added'] = this.date;
    data['body'] = this.body;
    data['approval'] = this.approval;
    return data;
  }

}

class Refund{
  bool onDiscount;
  int approval;
  String price;
  double quantity;
  double total;
  String requestDate;
  OrderItem orderItemId;
  int order_item_id;

  Refund({this.orderItemId, this.onDiscount, this.price, this.quantity, this.total, this.requestDate, this.order_item_id});

  Refund.fromJson(Map<String, dynamic> json)
  {
    //orderItemId = json['order_item'] != null ? new OrderItem.fromJson(json['order_item']) : null;
    order_item_id = json['order_item'];
    onDiscount = json['onDiscount'];
    approval = json['approval'];
    price = json['price'].toString();
    quantity = json['quantity'];
    total = json['total'];
    requestDate = json['request_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.orderItemId != null) {
      data['order_item'] = this.orderItemId.toJson();
    }
    data['onDiscount'] = this.onDiscount;
   // data['approval'] = this.approval;
    data['price'] = this.price;
    data['quantity'] = this.quantity;
    data['total'] = this.total;
    data['request_date'] = this.requestDate;
    return data;
  }

}
//


class AppColors
{
  static const Color primary = Colors.blueGrey;
  static const Color textColor = Colors.deepOrangeAccent;
  static const Color headingColor = Colors.orangeAccent;

}
class UserLoginForm {
  String username;
  String password;
  UserLoginForm({this.username, this.password});
}
class UserFromComment {// created for comment class
  String username;
  UserFromComment({this.username});
  UserFromComment.fromJson(Map<String, dynamic> json) {
    username = json['username'];

  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['username'] = this.username;
    return data;
  }
}
class Register {
  String username;
  String password;
  String email;
  String first_name;
  String last_name;

  Register(
      {this.first_name, this.last_name, this.email, this.username, this.password});

  Map<String, dynamic> toJson() {
    //benden sana kıyak
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['first_name'] = this.first_name;
    data['last_name'] = this.last_name;
    data['email'] = this.email;
    data['username'] = this.username;
    data['password'] = this.password;
    return data;
  }
}