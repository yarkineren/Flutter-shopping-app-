package com.example.cs308_plaqstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
