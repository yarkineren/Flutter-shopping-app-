// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility that Flutter provides. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'dart:ffi';

import 'package:cs308_plaqstore/forms/loginForm.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cs308_plaqstore/forms/checkout.dart';



void main() {
  testWidgets('Counter increments smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    // await tester.pumpWidget(MyApp());

    // Verify that our counter starts at 0.
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Tap the '+' icon and trigger a frame.
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // Verify that our counter has incremented.
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);
  });
}
void login() {

  test('empty username returns error string', () {

    final result = UserFieldValidator.validate('');
    expect(result, 'username can\'t be empty');
  });

  test('non-empty username returns null', () {

    final result = UserFieldValidator.validate('username');
    expect(result, null);
  });

  test('valid username returns string', () {

    final result = UserVFieldValidator.validate('username');
    expect(result, 'username is valid');
  });

  test('invalid username returns string', () {

    final result = UserIFieldValidator.validate('username');
    expect(result, 'username is invalid');
  });

  test('empty password returns error string', () {

    final result = PasswordFieldValidator.validate('');
    expect(result, 'password can\'t be empty');
  });

  test('non-empty password returns null', () {

    final result = PasswordFieldValidator.validate('password');
    expect(result, null);
  });

  test('valid password returns string', () {

    final result = PasswordVFieldValidator.validate('');
    expect(result, 'password is valid');
  });

  test('invalid password returns string', () {

    final result = PasswordIFieldValidator.validate('');
    expect(result, 'password is invalid');
  });

  test('empty email returns error string', () {

    final result = EmailFieldValidator.validate('email');
    expect(result, 'email can\'t be empty');
  });

  test('non-empty e-mail returns null', () {

    final result = EmailFieldValidator.validate('email');
    expect(result, null);
  });

  test('valid email returns string', () {

    final result = EmailVFieldValidator.validate('email');
    expect(result, 'email is valid');
  });

  test('invalid email returns string', () {

    final result = EmailIFieldValidator.validate('email');
    expect(result, 'email is invalid');
  });

}

void checkout() {

  test('empty card name returns error string', () {

    final result = CardNameFieldValidator.validate('');
    expect(result, 'card name can\'t be empty');
  });

  test('non-empty card name returns null', () {

    final result = CardNameFieldValidator.validate('card name');
    expect(result, null);
  });

  test('valid card name returns string', () {

    final result = CardNameVFieldValidator.validate('card name');
    expect(result, 'card name is valid');
  });

  test('invalid card name returns string', () {

    final result = CardNameIFieldValidator.validate('card name');
    expect(result, 'card name is invalid');
  });
                                                                                // card name
  test('empty card number returns error string', () {

    final result = CardNoFieldValidator.validate('');
    expect(result, 'card number can\'t be empty');
  });

  test('non-empty card number returns null', () {

    final result = CardNoFieldValidator.validate('card number');
    expect(result, null);
  });

  test('valid card number returns string', () {

    final result = CardNoVFieldValidator.validate('card number');
    expect(result, 'card number is valid');
  });

  test('invalid card number returns string', () {

    final result = CardNoIFieldValidator.validate('card number');
    expect(result, 'card number is invalid');
  });
                                                                                // card no
  test('empty card cvv returns error string', () {

    final result = CardCvvFieldValidator.validate('');
    expect(result, 'card cvv can\'t be empty');
  });

  test('non-empty card cvv returns null', () {

    final result = CardCvvFieldValidator.validate('card cvv');
    expect(result, null);
  });

  test('valid card cvv returns string', () {

    final result = CardCvvVFieldValidator.validate('card cvv');
    expect(result, 'card cvv is valid');
  });

  test('invalid card cvv returns string', () {

    final result = CardCvvIFieldValidator.validate('card cvv');
    expect(result, 'card cvv is invalid');
  });
                                                                                // card cvv
  test('empty expiration date returns error string', () {

    final result = CardDateFieldValidator.validate('');
    expect(result, 'expiration date can\'t be empty');
  });

  test('non-empty expiration date returns null', () {

    final result = CardDateFieldValidator.validate('expiration date');
    expect(result, null);
  });

  test('valid expiration date returns string', () {

    final result = CardDateVFieldValidator.validate('expiration date');
    expect(result, 'expiration date is valid');
  });

  test('invalid expiration date returns string', () {

    final result = CardDateIFieldValidator.validate('expiration date');
    expect(result, 'expiration date is invalid');
  });
                                                                               //expiration date
  test('empty address returns error string', () {

    final result = AddressFieldValidator.validate('');
    expect(result, 'address can\'t be empty');
  });

  test('non-empty address returns null', () {

    final result = AddressFieldValidator.validate('address');
    expect(result, null);
  });

  test('valid address returns string', () {

    final result = AddressVFieldValidator.validate('address');
    expect(result, 'address is valid');
  });

  test('invalid address returns string', () {

    final result = AddressIFieldValidator.validate('address');
    expect(result, 'address is invalid');
  });
                                                                                //address
  test('empty city returns error string', () {

    final result = CityFieldValidator.validate('');
    expect(result, 'city can\'t be empty');
  });

  test('non-empty city returns null', () {

    final result = CityFieldValidator.validate('city');
    expect(result, null);
  });

  test('valid city returns string', () {

    final result = CityVFieldValidator.validate('city');
    expect(result, 'city is valid');
  });

  test('invalid city returns string', () {

    final result = CityIFieldValidator.validate('city');
    expect(result, 'city is invalid');
  });
                                                                                //city
  test('empty state returns error string', () {

    final result = StateFieldValidator.validate('');
    expect(result, 'state can\'t be empty');
  });

  test('non-empty state returns null', () {

    final result = AddressFieldValidator.validate('state');
    expect(result, null);
  });

  test('valid state returns string', () {

    final result = AddressVFieldValidator.validate('state');
    expect(result, 'state is valid');
  });

  test('invalid state returns string', () {

    final result = AddressIFieldValidator.validate('state');
    expect(result, 'state is invalid');
  });
                                                                                //state
}
